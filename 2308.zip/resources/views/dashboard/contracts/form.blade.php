<div id="default-status" class="col-md-9" data-default-contract-status="{{ get_default_contract_status() }}">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="_cost" class="form-control-label">Trị giá (đồng)</i></label>
                <input id="_cost" type="text" class="form-control{{ $errors->has('cost') ? ' is-invalid' : '' }}" value="{{ old('cost', $record->cost) ? currency_format(old('cost', $record->cost)) : '' }}" autofocus required>
                <input id="cost" type="hidden" name="cost" value="{{ old('cost', $record->cost) }}">
                @if ($errors->has('cost'))
                    <div class="invalid-feedback">Giá trị {{ $errors->first('cost') }}</div>
                @endif
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-6 -->
        <div class="col-md-6">
            <div class="form-group">
                <label for="periods" class="form-control-label">Thời hạn</label>
                <select id="periods" name="periods" class="form-control{{ $errors->has('periods') ? ' is-invalid' : '' }}">
                    <option value="" {{ old('periods', $record->periods) == '' ? 'selected' : '' }}>Hãy chọn thời hạn</option>
                    @foreach ($classifies['periods'] as $period)
                        <option value="{{ $period->sub_id }}" {{ old('periods', $record->periods) == $period->sub_id ? 'selected' : '' }}>{{ $period->name }}</option>
                    @endforeach
                </select>
                @if ($errors->has('periods'))
                    <div class="invalid-feedback">Thời hạn {{ $errors->first('periods') }}</div>
                @endif
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-6 -->
    </div>
    <!-- row -->
</div>
<!-- /.col-md-9 -->
<input type="hidden" name="classifies" />