<div class=" table-responsive">     
    <table class="table table-hover">
        <th>#</th>
        <th>ID</th>
        <th>Trạng thái</th>
        <th style="min-width: 110px;">Loại</th>
        <th>Trị giá (đồng)</th>
        <th style="min-width: 100px;">Thời hạn (năm)</th>
        <th>Ngày mở HĐ</th>
        <th>Ngày đáo hạn</th>
        @if (! in_array($classifies['record_status'], [1, 3]))
            <th>Ngày đóng HĐ</th>
        @endif
        @if ($classifies['record_status'] != 2)
            <th style="width: 100px;">Hành động</th>
        @endif

        @foreach ($records as $record)
            <?php
                $tableCounter++;
                if ($record->deleted_at) {
                    $destroyToggleLink = route($resourceRoutesAlias.'.destroy', $record->id);
                    $formDestroyToggleId = 'formDestroyToggle_'.$record->id;
                }
                else {
                    if (! $record->open_confirmed_at) {
                        $editLink = route($resourceRoutesAlias.'.edit', $record->id);
                        $destroyToggleLink = route($resourceRoutesAlias.'.destroy', $record->id);
                        $formDestroyToggleId = 'formDestroyToggle_'.$record->id;
                    }
                    else {
                        if (! $record->closed_at) {
                            $downloadPDFLink = route($resourceRoutesAlias.'.downloadPDF', $record->id);
                            $closeToggleLink = route($resourceRoutesAlias.'.close', $record->id);
                            $formCloseToggleId = 'formCloseToggle_'.$record->id;
                        }
                        else {
                            if (! $record->close_confirmed_at && strtotime($record->due_date) > strtotime(now())) {
                                $closeToggleLink = route($resourceRoutesAlias.'.close', $record->id);
                                $formCloseToggleId = 'formCloseToggle_'.$record->id;
                            }
                        }
                    }
                }
            ?>
            @if (! $record->deleted_at && ! $record->open_confirmed_at)
                <tr title="Nhấn đúp để sửa" >
            @else 
                <tr>
            @endif
                <td>{{ $tableCounter }}</td>
                <td>
                    @if (! $record->deleted_at && ! $record->open_confirmed_at)
                        <a href="{{ $editLink }}">{{ $record->id }}</a>
                    @else {{ $record->id }} @endif
                </td>
                <td>
                    @if ($record->deleted_at) 
                        <span class="badge bg-dark">{{ $classifies['record_statuses'][4]->name }}</span>
                    @else
                        @if (! $record->open_confirmed_at) 
                            <span class="badge bg-primary">{{ $classifies['record_statuses'][0]->name }}</span>
                        @else
                            @if (! $record->closed_at)
                                <span class="badge bg-success">{{ $classifies['record_statuses'][1]->name }}</span>
                            @else
                                @if (! $record->close_confirmed_at)
                                    <span class="badge bg-warning">{{ $classifies['record_statuses'][2]->name }}</span>
                                @else
                                    <span class="badge bg-secondary">{{ $classifies['record_statuses'][3]->name }}</span>
                                @endif
                            @endif
                        @endif
                    @endif
                </td>
                <td>{{ $record->type_name }}</td>
                <td>{{ currency_format($record->cost) }}</td>
                <td>{{ $record->periods_name }}</td>
                <td>{{ date("d/m/Y", strtotime($record->opened_at)) }}</td>
                <td>{{ date("d/m/Y", strtotime($record->due_date)) }}</td>
                @if (! in_array($classifies['record_status'], [1, 3]))
                    <td>{{ $record->closed_at ? date("d/m/Y", strtotime($record->closed_at)) : '' }}</td>
                @endif

                <!-- we will also add show, edit, and delete buttons -->
                @if ($classifies['record_status'] != 2)
                <td>
                    @if (!(!$record->deleted_at && $record->open_confirmed_at && $record->closed_at && $record->close_confirmed_at))
                    <div class="btn-group">
                        <button type="button" class="btn btn-skin btn-{{ $record->deleted_at ? 'dark' : $color->skin }} dropdown-toggle" data-toggle="dropdown"></button>
                        <div class="dropdown-menu">
                            @if ($record->deleted_at) 
                                <a href="#" class="dropdown-item btnDeleteToggle load-none" data-form-id="{{ $formDestroyToggleId }}" data-status="1"><i class="fas fa-trash-alt text-dark"></i> Khôi phục</a>
                            @else
                                @if (! $record->open_confirmed_at) 
                                    <a href="{{ $editLink }}" class="dropdown-item edit"><i class="fas fa-edit text-info"></i> Sửa</a>
                                    <a href="#" class="dropdown-item btnDeleteToggle load-none" data-form-id="{{ $formDestroyToggleId }}" data-status="2"><i class="fas fa-trash-alt text-danger"></i> Xóa</a>
                                @else
                                    @if (! $record->closed_at)
                                        <a href="{{ $downloadPDFLink }}" class="dropdown-item load-none"><i class="fas fa-download text-secondary"></i> Tải file PDF</a>
                                        <a href="#" class="dropdown-item btnCloseToggle load-none" data-form-id="{{ $formCloseToggleId }}" data-status="2"><i class="fas fa-stop-circle text-success"></i> Đóng</a>
                                    @else
                                        @if (! $record->close_confirmed_at)
                                            <a href="#" class="dropdown-item btnCloseToggle load-none" data-form-id="{{ $formCloseToggleId }}" data-status="1"><i class="fas fa-stop-circle text-dark"></i> Hủy đóng</a>
                                        @endif
                                    @endif
                                @endif
                            @endif
                        </div>
                    </div>
                    @endif

                    @if ($record->deleted_at) 
                            <!-- Enable Record Form -->
                            <form id="{{ $formDestroyToggleId }}" action="{{ $destroyToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                {{ csrf_field() }}
                                {{ method_field('DELETE') }}
                                <input type="hidden" name="classifies" />
                            </form>
                    @else
                        @if (! $record->open_confirmed_at) 
                            <!-- Disable Record Form -->
                            <form id="{{ $formDestroyToggleId }}" action="{{ $destroyToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                {{ csrf_field() }}
                                {{ method_field('DELETE') }}
                                <input type="hidden" name="classifies" />
                            </form>
                        @else
                            @if (! $record->closed_at)
                                <!-- Close Contract Form -->
                                <form id="{{ $formCloseToggleId }}" action="{{ $closeToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="classifies" />
                                </form>
                            @else
                                @if (! $record->close_confirmed_at)
                                    <!-- Cancel Contract Form -->
                                    <form id="{{ $formCloseToggleId }}" action="{{ $closeToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                        {{ csrf_field() }}
                                        <input type="hidden" name="classifies" />
                                    </form>
                                @endif
                            @endif
                        @endif
                    @endif
                </td>
                @endif
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
