<?php
  $color = get_color();
?>

{{-- Extends Layout --}}
@extends('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin])

{{-- Breadcrumbs --}}
@section('breadcrumbs')
    {!! Breadcrumbs::render('messages') !!}
@endsection

{{-- Page Title --}}
@section('page-title', 'Tin nhắn')

{{-- Header Extras to be Included --}}
@section('head-extras')
  <link rel="stylesheet" href="{{ asset('dist/_partials/select2/select2.css') }}">
  <link rel="stylesheet" href="{{ asset('dist/dashboard/messages/messages.css') }}">
@endsection

@section('content')
  <div class="row">
    <div class="col-md-4">
      <!-- Find contacter -->
      <div class="card">
        <div class="card-body p-0">
          <select id="contact" class="form-control load">
            <option value="">&nbsp;</option>
            @foreach ($contacts as $contact)
              <option value="{{ route('dashboard::messages', ['id' => $contact->id]) }}">{{ $user->is_admin ? $contact->name : 'Nhân viên hỗ trợ '.$contact->id }}</option>
            @endforeach
          </select>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->
      <!-- Find Group -->
      @if ($groups)
      <div class="card">
        <div class="card-body p-0">
          <select id="group" class="form-control load">
            <option value="">&nbsp;</option>
            @foreach ($groups as $_group)
              <option value="{{ route('dashboard::messages', ['group' => $_group->sub_id]) }}">{{ $_group->name }}</option>
            @endforeach
          </select>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->
      @endif
      <!-- inbox -->
      <div id="inbox" class="card">
        <div class="card-header">
          <h3 class="card-title">Hộp thoại</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body p-0">
          <form id="formInbox" method="GET" action="{{ route('dashboard::messages', ['id' => ($contacter ? $contacter->id : ''), 'group' => $group]) }}">
            <div class="input-group" style="width: 100%;">
              <input type="text" name="inbox" class="form-control float-right" value="{{ $inbox }}" placeholder="Tìm kiếm" {{$group || $contacter ? '' : 'autofocus' }}>
              <div class="input-group-append">
                <button type="submit" class="btn btn-skin btn-{{ $color->skin }}"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </form>
          <div class="container">
            @foreach ($inboxs as $inbox)
              <a href="{{ route('dashboard::messages', ['id' => $inbox->contacter_id]) }}" class="message-item" data-contacter-id="{{ $inbox->contacter_id }}">
                <div class="media">
                  <img src="{{ asset('uploads/avatar/'.$inbox->avatar) }}" alt="Ảnh đại diện người trò chuyện" class="img-size-50 mr-3 img-circle">
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      {{ $inbox->name }}
                      <span class="float-right text-sm {{ $inbox->unread_count ? '' : 'hide' }}">
                        <span title="Tin nhắn chưa đọc" class="badge badge-danger">{{ $inbox->unread_count }}</span>
                      </span>
                    </h3>
                    <div class="text-sm content">{{ $inbox->content }}</div>
                    <div class="text-sm text-muted"><i class="fa fa-clock mr-1"></i> <span class="time">{{ Carbon::parse($inbox->created_at)->diffInDays(Carbon::now()) > 1 ? date("d/m/Y", strtotime($inbox->created_at)) : date("H:i", strtotime($inbox->created_at)) }}</span></div>
                  </div>
                </div>
              </a>
              <div class="message-divider"></div>
            @endforeach
          </div>
        </div>
        <!-- /.card-body -->
      </div>
    </div>
    <!-- /.col-md-4 -->
    <!-- Chatting Window -->
    <div class="col-md-8">
      <div class="card card-skin card-{{ $color->skin }} card-outline direct-chat direct-chat-{{ $color->skin }}">
          <div class="card-header">
            <h3 class="card-title">{{ $group ?  $group->name : ($contacter ? $contacter->name : 'Cửa sổ trò chuyện') }}</h3>
          </div>
        <!-- /.card-header -->
        @if($group || $contacter)
          <div class="card-body">
            <!-- Conversations are loaded here -->
            <div class="direct-chat-messages">
              @if ($contacter)
                @includeIf('dashboard.messages.message')
              @endif
            </div>
            <!--/.direct-chat-messages-->
          </div>
          <!-- /.card-body -->
          <div class="card-footer">
            <div class="input-group">
              <div class="message-effect hide">Nhập tin nhắn ...</div>
              <input type="text" id="messageContent" name="message" placeholder="Nhập tin nhắn ..." class="form-control" autofocus>
              <span class="input-group-append">
                <span id="btnSend" class="btn btn-skin btn-{{ $color->skin }}">Gửi</span>
              </span>
              <div class="hide" id="messageInfo" data-id="" data-save-url="{{ route('dashboard::messages.save') }}" data-destroy-url="{{ route('dashboard::messages.destroy') }}" data-markAsRead-url="{{ route('dashboard::messages.markAsRead') }}"></div>
              <div class="hide" id="myInfo" data-id="{{ $user->id }}" data-name="{{ $user->name }}" data-avatar="{{ asset('uploads/avatar/'.$user->avatar) }}"></div>
              @if ($contacter)
                <div class="hide" id="contacterInfo" data-id="{{ $contacter->id }}" data-name="{{ $contacter->name }}" data-avatar="{{ asset('uploads/avatar/'.$contacter->avatar) }}"></div>
              @else
                <div class="hide" id="groupInfo" data-id="{{ $group->sub_id }}"></div>
              @endif
            </div>
          </div>
          <!-- /.card-footer-->
        @else 
          <div class="card-body">
            <div class="direct-chat-messages">Hãy chọn người trò chuyện</div>
          </div>
        @endif
      </div>
    </div>
    <!-- /.col-md-8 -->
  </div>
  <!-- /.row -->
  <div id='chat'>
    <chat></chat>
  </div>
@endsection

{{-- Footer Extras to be Included --}}
@section('footer-extras')
  <script src="{{ asset('/dist/_partials/select2/select2.js') }}"></script>
  <script src="{{ asset('/dist/dashboard/messages/messages.js') }}"></script>
  <script src="{{ asset('/dist/dashboard/messages/chat.js') }}"></script>
@endsection
