@if($messages)
  <?php
    $user = Auth::user();
    $pre_msg_sender_id = '';
    $pre_msg_time = '1900-01-01 00:00';
  ?>
  @foreach ($messages as $message)
    <?php
      
      $is_send_msg = $user->id == $message->sender_id ? 1 : 0;
      $sender = $is_send_msg ? $user : App\User::find($message->sender_id);
      $message_time = Carbon::parse($message->created_at)->diffInDays(Carbon::now()) > 1 ? date("d/m/Y", strtotime($message->created_at)) : date("H:i", strtotime($message->created_at));
      $sender_name = (strpos($sender->name, ' ') === false) ? '' : preg_replace('#.*\s([\w-]*)$#', '$1', $sender->name);
    ?>
    <!-- Message. Default to the left -->
    <div class="direct-chat-msg {{ $is_send_msg ? 'right' : '' }} {{ $pre_msg_sender_id != $sender->id ? '' : 'none' }}" data-msg-id="{{ $message->id }}" data-sender-id="{{ $sender->id }}">
        <div class="direct-chat-info clearfix {{ $pre_msg_sender_id != $sender->id ? '' : 'hide' }}">
          <span class="direct-chat-name float-{{ $is_send_msg ? 'right' : 'left' }}">
            {{ $is_send_msg ? 'Tôi' : split_name($sender->name, 'lastname') }}
            <span class="direct-chat-timestamp float-{{ $is_send_msg ? 'left' : 'right' }} ml-2 mr-2">{{ $message_time }}</span>
          </span>
          
        </div>
        <!-- /.direct-chat-info -->
        <a href="{{ !$is_send_msg && $user->is_admin ? route('admin::users.index', ['id' => $message->sender_id]) : '#' }}" class="{{ !$is_send_msg && $user->is_admin ? '' : 'load-none' }} {{ $pre_msg_sender_id != $sender->id ? '' : 'hide' }}"><img class="direct-chat-img" src="{{ asset('uploads/avatar/'.$sender->avatar) }}"></a>
        <!-- /.direct-chat-img -->
      <div class="direct-chat-text" title="{{ $message_time }}">
        @if ($is_send_msg)
          <a class="hide destroy load-none"><i class="fas fa-trash-alt"></i>&nbsp;</a>
          <a class="hide edit load-none"><i class="fas fa-pencil-alt"></i>&nbsp;</a>
        @endif
        <span>{{ $message->content }}</span>
      </div>  
      <!-- /.direct-chat-text -->
    </div>
    <!-- /.direct-chat-msg -->
    <?php
      $pre_msg_sender_id = $sender->id;
      $pre_msg_time = $message->created_at;
    ?>
  @endforeach
@endif