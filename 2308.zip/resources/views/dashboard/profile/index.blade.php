<?php
  $color = get_color();
?>

{{-- Extends Layout --}}
@extends('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin])

{{-- Breadcrumbs --}}
@section('breadcrumbs')
    {!! Breadcrumbs::render('profile') !!}
@endsection

{{-- Page Title --}}
@section('page-title', 'Hồ sơ cá nhân')

{{-- Header Extras to be Included --}}
@section('head-extras')
    <link rel="stylesheet" href="{{ asset('dist/_partials/datepicker/datepicker.css') }}">
    <link rel="stylesheet" href="{{ asset('dist/_partials/avatar/avatar.css') }}">
    <link rel="stylesheet" href="{{ asset('dist/_partials/select2/select2.css') }}">
    <link rel="stylesheet" href="{{ asset('dist/dashboard/profile/profile.css') }}">
@endsection

@section('content')
    <div class="row">
        <div class="col-md-3">
            <!-- Profile Image -->
            <div class="card card-skin card-{{ $color->skin }} card-outline">
                <!--<div class="text-center">-->
                <!--    <div id="upload-demo" class="avatar-resize" style="opacity: 0;">-->
                <!--        <button type="button" id="btnCancel" class="btn mb-2"><i class="fas fa-ban"></i> Hủy</button>-->
                <!--        &nbsp;&nbsp;&nbsp;&nbsp;-->
                <!--        <button type="button" id="btnUpload" class="btn mb-2"><i class="fas fa-save"></i> Lưu</button>-->
                <!--    </div>-->
                <!--</div>-->
                <!-- /.text-center -->
                <div class="card-body">
                    <div class="text-center">
                       <div class="avatar-container">
                            <!--<div class="avatar-edit">-->
                            <!--    <input type='file' id="imageUpload" accept=".png, .jpg, .jpeg"/>-->
                            <!--    <label for="imageUpload" class="pt-1"><i class="fas fa-pencil-alt"></i></label>-->
                            <!--</div>-->
                            <div class="avatar-preview">
                                <div id="imagePreview" style="background-image: url({{ Auth::user()->getAvatarPath() }});">
                                </div>
                            </div>
                        </div>
                        <!-- /.avatar-container -->
                    </div>
                    <!-- /.text-center -->
                    <h3 class="text-center">{{ Auth::user()->name }}</h3>
                    <p class="text-muted text-center">{{ \App\Utils::getUserRoleLabel() }}</p>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col-md-3 -->
        <div class="col-md-9">
            <div class="card">
                <form method="POST" action="{{ route('dashboard::profile.update') }}">
                    {{ csrf_field() }}
                    <div class="card-body">                       
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="form-control-label">Họ tên <i class="far fa-question-circle" title="Họ tên phải khớp với CMND"></i></label>
                                    <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name', Auth::user()->name) }}" pattern="[A-Za-z].{5,}" required autofocus>
                                    @if ($errors->has('name'))
                                        <div class="invalid-feedback">Họ tên {{ $errors->first('name') }}</div>
                                    @endif
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <!-- col-md-6 -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="username" class="form-control-label">CMND</label>
                                    <input id="username" type="text" class="form-control{{ $errors->has('username') ? ' is-invalid' : '' }}" name="username" value="{{ old('username', Auth::user()->username) }}" pattern="[0-9]{9}" required>
                                    @if ($errors->has('username'))
                                        <div class="invalid-feedback">CMND {{ $errors->first('username') }}</div>
                                    @endif
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <!-- col-md-6 -->
                        </div>
                        <!-- row -->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password" class="form-control-label">Mật khẩu <i class="far fa-question-circle" title="Mật khẩu phải chứa ít nhất một số, một chữ hoa, một chữ thường và ít nhất 6 ký tự trở lên"></i></label>
                                    <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" value="{{ old('password') }}">
                                    @if ($errors->has('password'))
                                        <div class="invalid-feedback">Mật khẩu {{ $errors->first('password') }}</div>
                                    @endif
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <!-- col-md-6 -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password-confirm" class="form-control-label">Xác nhận mật khẩu</label>
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <!-- col-md-6 -->
                        </div>
                        <!-- row -->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="gender" class="form-control-label">Giới tính</label>
                                    <select id="gender" name="gender" class="form-control{{ $errors->has('gender') ? ' is-invalid' : '' }}">
                                        <!-- <option value="" {{ old('gender', Auth::user()->gender) == '' ? 'selected' : '' }}>Chọn giới tính</option>
                                        <option value="1" {{ old('gender', Auth::user()->gender) == '1' ? 'selected' : '' }}>Nam</option>
                                        <option value="0" {{ old('gender', Auth::user()->gender) == '0' ? 'selected' : '' }}>Nữ</option> -->
                                        
                                        <option value="" {{ old('gender', Auth::user()->gender) == '' ? 'selected' : '' }}>Chọn giới tính</option>
                                        @foreach ($classifies['genders'] as $gender)
                                            <option value="{{ $gender->value }}" {{ old('gender', Auth::user()->gender) == $gender->value ? 'selected' : '' }}>{{ $gender->name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('gender'))
                                        <div class="invalid-feedback">Giới tính {{ $errors->first('gender') }}.</div>
                                    @endif
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <!-- col-md-6 -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="birthday" class="form-control-label">Ngày sinh <i class="far fa-question-circle" title="Ngày sinh phải có dạng DD/MM/YYYY"></i></label>
                                    <div class="input-group date">
                                      <input id="birthday" type="text" class="form-control{{ $errors->has('birthday') ? ' is-invalid' : '' }}" name="birthday" value="{{ old('birthday', Carbon::parse(Carbon::createFromFormat('Y-m-d', Auth::user()->birthday))->format('d/m/Y')) }}" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])/(?:0[1-9]|1[0-2]))|(30/(?:01|0[3-9]|1[0-2]))|(31/(?:0[13578]|1[02])))/((?:19|20)[0-9]{2})" required>
                                      <span class="input-group-text input-group-addon"><i class="fa fa-calendar"></i></span>
                                    </div>
                                    @if ($errors->has('birthday'))
                                        <div class="invalid-feedback">Ngày sinh {{ $errors->first('birthday') }}</div>
                                    @endif
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <!-- col-md-6 -->
                        </div>
                        <!-- row -->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="residence" class="form-control-label">Nơi cư trú <i class="far fa-question-circle" title="Ví dụ: Thôn 4, Quế Thuận, Quế Sơn, Quảng Nam"></i></label>
                                    <input id="residence" type="text" class="form-control{{ $errors->has('residence') ? ' is-invalid' : '' }}" name="residence" value="{{ old('residence', Auth::user()->residence) }}" pattern="(.{4,})(, )(.{5,})(, )(.{5,})(, )(.{5,})" required>
                                    @if ($errors->has('residence'))
                                        <div class="invalid-feedback">Nơi cư trú {{ $errors->first('residence') }}</div>
                                    @endif
                                </div>  
                                <!-- /.form-group -->
                            </div>
                            <!-- col-md-6 -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone" class="form-control-label">Số điện thoại</label>
                                    <input id="phone" type="text" class="form-control{{ $errors->has('phone') ? ' is-invalid' : '' }}" name="phone" value="{{ old('phone', Auth::user()->phone) }}" pattern="0(?:8|9|12|16)[0-9]{8}" required>
                                    @if ($errors->has('phone'))
                                        <div class="invalid-feedback">Số điện thoại {{ $errors->first('phone') }}</div>
                                    @endif
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <!-- col-md-6 -->
                        </div>
                        <!-- row -->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email" class="form-control-label">Email</label>
                                    <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email', Auth::user()->email) }}" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
                                    @if ($errors->has('email'))
                                        <div class="invalid-feedback">Email {{ $errors->first('email') }}</div>
                                    @endif
                                </div>
                                 <!--/.form-group -->
                            </div>
                        </div>
                        <!-- row -->
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <button type="submit" class="btn btn-skin btn-{{ $color->skin }}"><i class="fas fa-save"></i> Lưu</button>
                        &nbsp;
                        <a href="{{ route('dashboard::profile.downloadPDF') }}" class="btn btn-secondary load-none"><i class="fas fa-download"></i> Tải hợp đồng</a>
                    </div>
                    <!-- /.card-footer -->
                </form>
                <!-- /form -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col-md-9 -->
    </div>
    <!-- /.row -->
@endsection

{{-- Footer Extras to be Included --}}
@section('footer-extras')
    <script src="{{ asset('/dist/_partials/datepicker/datepicker.js') }}"></script>
    <script src="{{ asset('/dist/_partials/select2/select2.js') }}"></script>
    <script src="{{ asset('/dist/dashboard/profile/profile.js') }}"></script>
@endsection
