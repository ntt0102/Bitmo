<div class=" table-responsive">    
    <table class="table table-hover">
        <th>#</th>
        <th>Trạng thái</th>
        <th>Loại thông báo</th>
        <th>Thời gian nhận</th>
        @if (Auth::user()->is_admin)
            <th style="min-width: 180px;">Người gửi</th>
        @endif
        <th style="width: 80px;">Hành động</th>

        @foreach ($records as $record)
            <?php
                $tableCounter++;
                $data = json_decode($record->data, true);
                $sender_name = App\User::find($data['sender_id'])->name;
                //
                switch ($record->type_sub_id) {
                    case 2:
                        $paidMoneyConfirmLink = route('admin::money_transactions.confirm', $data['money_transaction_id']);
                        $formPaidMoneyConfirmId = 'formPaidMoneyConfirm_'.$data['money_transaction_id'];
                        break;
                    case 3:
                        $withdrawedMoneyConfirmLink = route('admin::money_transactions.confirm', $data['money_transaction_id']);
                        $formWithdrawedMoneyConfirmId = 'formWithdrawedMoneyConfirm_'.$data['money_transaction_id'];
                        break;
                    case 4:
                    case 5:
                        $markAsReadLink = route($resourceRoutesAlias.'.markAsRead', $record->notification_id);
                        $formMarkAsReadId = 'formMarkAsRead_'.$record->notification_id;
                        $listMoneyTransactionLink = route('dashboard::money_transactions.index').'?id='.$data['money_transaction_id'];
                        break;
                }
            ?>
            <tr>
                <td>{{ $tableCounter }}</td>
                <td>
                    @if ($record->read_at)
                        <span class="badge bg-secondary">{{ $classifies['statuses'][1]->name }}</span>
                    @else
                        <span class="badge bg-success">{{ $classifies['statuses'][0]->name }}</span>
                    @endif
                </td>
                <td>
                @switch($record->type_sub_id)
                    @case(1)
                        <span class="badge bg-info">
                        @break
                    @case(2)
                        <span class="badge bg-primary">
                        @break
                    @case(3)
                        <span class="badge bg-warning">
                        @break
                    @case(4)
                        <span class="badge bg-success">
                        @break
                    @case(5)
                        <span class="badge bg-dark">
                        @break
                @endswitch
                            {{ $record->type_name }}
                        </span>
                </td>
                <td>{{ date("H:i d/m/Y", strtotime($record->created_at)) }}</td>
                @if (Auth::user()->is_admin)
                    <td>{{ $sender_name }}</td>
                @endif
                
                <!-- we will also add show, edit, and delete buttons -->
                <td>
                    @if($record->type_sub_id != 1) 
                        <div class="btn-group">
                            <button type="button" class="btn btn-skin btn-{{ $record->deleted_at ? 'dark' : $color->skin }} dropdown-toggle" data-toggle="dropdown"></button>
                            <div class="dropdown-menu">
                                @switch($record->type_sub_id)
                                    @case(2)
                                        @if (! $record->read_at)
                                            <a href="#" class="dropdown-item btnPaidMoneyConfirm load-none" data-form-id="{{ $formPaidMoneyConfirmId }}"><i class="fas fa-check text-primary"></i> Xác nhận nộp tiền</a>
                                        @endif
                                        @break
                                    @case(3)
                                        @if (! $record->read_at)
                                            <a href="#" class="dropdown-item btnWithdrawedMoneyConfirm load-none" data-form-id="{{ $formWithdrawedMoneyConfirmId }}"><i class="fas fa-check-double text-warning"></i> Xác nhận rút tiền</a>
                                        @endif
                                        @break
                                    @case(4)
                                    @case(5)
                                        <a href="#" class="dropdown-item btnMarkAsRead load-none" data-form-id="{{ $formMarkAsReadId }}"><i class="fas fa-info text-info"></i> Xem trạng thái giao dịch</a>
                                        @break
                                @endswitch
                            </div>
                        </div>
                    @endif
                    @switch($record->type_sub_id)
                        @case(2)
                            @if (! $record->read_at)
                                <!-- Open Confirm Contract Form -->
                                <form id="{{ $formPaidMoneyConfirmId }}" action="{{ $paidMoneyConfirmLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="classifies" />
                                    <input type="hidden" name="notification_id" value="{{ $record->notification_id }}"/>
                                </form>
                            @endif
                            @break
                        @case(3)
                            @if (! $record->read_at)
                                <!-- Close Confirm Contract Form -->
                                <form id="{{ $formWithdrawedMoneyConfirmId }}" action="{{ $withdrawedMoneyConfirmLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="classifies" />
                                    <input type="hidden" name="notification_id" value="{{ $record->notification_id }}" />
                                </form>
                            @endif
                            @break
                        @case(4)
                        @case(5)
                            <!-- Mark As Read Form -->
                            <form id="{{ $formMarkAsReadId }}" action="{{ $markAsReadLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                {{ csrf_field() }}
                                <input type="hidden" name="classifies" value="{{ $listMoneyTransactionLink }}" />
                            </form>
                            @break
                    @endswitch
                </td>
            </tr>
        @endforeach
    </table>
</div>
