<div class=" table-responsive">     
    <table class="table table-hover">
        <th>#</th>
        <th>Loại</th>
        <th>Bảng</th>
        <th>Chức năng</th>
        <th>Lỗi</th>
        <th>Ghi chú</th>
        <th>Tạo lúc</th>
        <th>Tạo bởi</th>

        @foreach ($records as $record)
            <?php
                $tableCounter++;
            ?>
            <tr>
                <td>{{ $tableCounter }}</td>
                <td>
                @switch($record->type)
                    @case(1)
                        <span class="badge bg-primary">
                        @break
                    @case(2)
                        <span class="badge bg-success">
                        @break
                    @case(3)
                        <span class="badge bg-warning">
                        @break
                    @case(4)
                        <span class="badge bg-dark">
                        @break
                @endswitch
                            {{ $record->type_name }}
                        </span>
                </td>
                <td>{{ $record->table_name ? $record->table_name : $record->table }}</td>
                <td>{{ $record->action_name ? $record->action_name : $record->action }}</td>
                <td><i class="far {{ $record->is_error ? 'fa-check-square' : 'fa-square' }}"></i></td>
                <td>{{ $record->note }}</td>
                <td>{{ date("H:i d/m/Y", strtotime($record->created_at)) }}</td>
                <td>{{ $record->modified_name }}</td>
            </tr>
        @endforeach
    </table>
</div>
