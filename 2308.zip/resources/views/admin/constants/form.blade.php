<div id="default-record-status" class="col-md-9" data-default-record-status="{{ get_default_record_status() }}">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="name" class="form-control-label">Tên</label>
                <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name', $record->name) }}"  autofocus>
                @if ($errors->has('name'))
                    <div class="invalid-feedback">Tên {{ $errors->first('name') }}</div>
                @endif
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-6 -->
        <div class="col-md-6">
            <div class="form-group">
                <label for="_value" class="form-control-label">Giá trị</i></label>
                <input id="_value" type="text" class="form-control{{ $errors->has('value') ? ' is-invalid' : '' }}" value="{{ is_numeric(old('value', $record->value)) && $record->value >= 1000000 ? currency_format(old('value', $record->value)) : $record->value }}" required>
                <input id="value" type="hidden" name="value" value="{{ old('value', $record->value) }}">
                @if ($errors->has('value'))
                    <div class="invalid-feedback">Giá trị {{ $errors->first('value') }}</div>
                @endif
            </div>
            <!-- /.form-group --> 
        </div>
        <!-- col-md-6 -->
    </div>
    <!-- row -->
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <div class="custom-control custom-checkbox mt-1">
                    <input type="checkbox" class="custom-control-input" id="is_array" name="is_array" {{ old('is_array', $record->is_array) ? 'checked' : '' }}>
                    <label class="custom-control-label" for="is_array">Kiểu mảng</label>
                </div>
                <!-- /.custom-control -->
                @if ($errors->has('is_array'))
                    <div class="invalid-feedback">{{ $errors->first('is_array') }}</div>
                @endif
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-6 -->
    </div>
    <!-- row -->
</div>
<!-- /.col-md-9 -->
<input type="hidden" name="classifies" />