<script src="{{ asset('/dist/'.str_replace('.', '/', $resourceAlias).'/filter.js') }}"></script>
