<div class=" table-responsive">
    <table class="table table-hover">
        <th>#</th>
        <th>ID</th>
        <th style="min-width: 180px;">Thuộc nhóm</th>
        <th style="min-width: 100px;">ID thứ cấp</th>
        <th style="min-width: 100px;">Thứ tự hiển thị</th>
        <th style="min-width: 150px;">Tên hiển thị</th>
        <th>Giá trị</th>
        <th>Cập nhật lúc</th>
        <th style="min-width: 100px;">Cập nhật bởi</th>
        @if ($classifies['record_status'] != get_default_record_status())
            <th style="min-width: 100px;">Đã xóa lúc</th>
        @endif
        <th style="width: 100px;">Sự kiện</th>
    
        @foreach ($records as $record)
            <?php
            $tableCounter++;
            if (! $record->deleted_at) {
                $editLink = route($resourceRoutesAlias.'.edit', $record->id);
            }
            $destroyToggleLink = route($resourceRoutesAlias.'.destroy', $record->id);
            $formDestroyToggleId = 'formDestroyToggle_'.$record->id;
            ?>
            @if (! $record->deleted_at)
                    <tr class="load" title="Nhấn đúp để sửa" >
            @else 
                <tr>
            @endif
                <td>{{ $tableCounter }}</td>
                <td>
                    @if (! $record->deleted_at)
                        <a href="{{ $editLink }}">{{ $record->id }}</a>
                    @else {{ $record->id }} @endif
                </td>
                <td>{{ $record->group_name }}</td>
                <td>{{ $record->sub_id }}</td>
                <td>{{ $record->display_no }}</td>
                <td>{{ $record->name }}</td>
                <td>{{ $record->value }}</td>
                <td>{{ date("H:i d/m/Y", strtotime($record->updated_at)) }}</td>
                <td>{{ $record->modified_name }}</td>
                @if ($classifies['record_status'] != '1')
                    <td>{{ $record->deleted_at ? date("H:i d/m/Y", strtotime($record->deleted_at)) : ''}}</td>
                @endif
                <!-- we will also add show, edit, and delete buttons -->
                <td>
                    <div class="btn-group">
                        <button type="button" class="btn btn-skin btn-{{ $record->deleted_at ? 'dark' : $color->skin }} dropdown-toggle" data-toggle="dropdown"></button>
                        <div class="dropdown-menu">
                            @if (! $record->deleted_at)
                                <a href="{{ $editLink }}" class="dropdown-item edit"><i class="fas fa-edit text-info"></i> Sửa</a>
                            @endif
                            <a href="#" class="dropdown-item btnDeleteToggle load-none" data-form-id="{{ $formDestroyToggleId }}" data-status="{{ $record->deleted_at ? '1' : '2'}}" >
                                @if ($record->deleted_at)
                                    <i class="fas fa-window-restore text-dark"></i>
                                @else
                                    <i class="fas fa-trash-alt text-danger"></i>
                                @endif
                                {{ $record->deleted_at ? 'Khôi phục' : 'Xóa'}}
                            </a>
                        </div>
                    </div>
                    
                    <!-- Disable/Enable Record Form -->
                    <form id="{{ $formDestroyToggleId }}" action="{{ $destroyToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                        {{ csrf_field() }}
                        {{ method_field('DELETE') }}
                        <input type="hidden" name="classifies" />
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
