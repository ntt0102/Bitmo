<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label for="record-status" class="form-control-label">Trạng thái {{ $_pageTitleLower }}</label>
            <select id="record-status" name="record-status" class="form-control load">
                <option value="0" {{ $classifies['record_status'] == '' ? 'selected' : '' }}>Tất cả</option>
                @foreach ($classifies['record_statuses'] as $record_status)
                    <option value="{{ $record_status->sub_id }}" {{ $classifies['record_status'] == $record_status->sub_id ? 'selected' : '' }}>{{ $record_status->name }}</option>
                @endforeach
            </select>
        </div>
        <!-- form-group -->
    </div>
    <!-- col-md-3 -->
    <div class="col-md-3">
        <div class="form-group">
            <label for="group" class="form-control-label">Nhóm danh mục</label>
            <select id="group" name="group" class="form-control load">
                <option value="0" {{ $classifies['group'] == '' ? 'selected' : '' }}>Tất cả</option>
                @foreach ($classifies['groups'] as $group)
                    <option value="{{ $group->id }}" {{ $classifies['group'] == $group->id ? 'selected' : '' }}>{{ $group->name }}</option>
                @endforeach
            </select>
        </div>
        <!-- form-group -->
    </div>
    <!-- col-md-3 -->
</div>
<!-- row -->
