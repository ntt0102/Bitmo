<form id="formAdd" action="{{ route('admin::group-members.add') }}" method="POST">
    {{ csrf_field() }}
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Thêm thành viên</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body p-1">
            <div class="form-group">
                <select id="group" name="group" class="form-control load">
                    <option value="">&nbsp;</option>
                    @foreach ($classifies['groups'] as $group)
                        <option value="{{ $group->sub_id }}" {{ $classifies['group'] == $group->sub_id ? 'selected' : '' }}>{{ $group->name }}</option>
                    @endforeach
                </select>
            </div>
            <!-- form-group -->
            <div class="input-group member" style="width: 100%;">
                    <select id="_member" class="form-control"></select>
                    <select id="member" name="member[]" class="form-control hide" multiple>
                        @if ($classifies['group']){
                            @foreach ($classifies['users'] as $user)
                                <option value="{{ $user->id }}">{{ $user->name }}</option>
                            @endforeach
                        @endif
                    </select>
                <div class="input-group-append">
                    <button type="button" id="btnAdd" class="btn btn-skin btn-{{ $color->skin }}"><i class="fas fa-chevron-right"></i></button>
                </div>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
</form>
