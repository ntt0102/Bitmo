<div class=" table-responsive">     
    <table class="table table-hover">
        <th>#</th>
        <th style="min-width: 180px;">Họ tên</th>
        <th>Số CMND</th>
        <th style="min-width: 180px;">Nơi cư trú</th>
        <th>Cập nhật lúc</th>
        <th>Cập nhật bởi</th>
        <th>Sự kiện</th>

        @foreach ($records as $record)
            <?php
                $tableCounter++;
                $destroyLink = route('admin::group-members.destroy', $record->id);
                $formDestroyId = 'formDestroy_'.$record->id;
            ?>
            <tr>
                <td>{{ $tableCounter }}</td>
                <td>{{ $record->user_name }}</td>
                <td>{{ $record->user_username }}</td>
                <td>{{ $record->user_residence }}</td>
                <td>{{ date("H:i d/m/Y", strtotime($record->updated_at)) }}</td>
                <td>{{ $record->modified_name }}</td>
                <td>
                    <div class="btn-group float-right">
                        <span class="btn btn-danger btn-sm btnDelete" data-form-id="{{ $formDestroyId }}" title="Xóa {{ $record->user_name }}"><i class="fas fa-times"></i></span>
                    </div>
                    <!-- Destroy Record Form -->
                    <form id="{{ $formDestroyId }}" action="{{ $destroyLink }}" method="POST" style="display: none;" class="hidden form-inline">
                        {{ csrf_field() }}
                        <input type="hidden" name="group"/>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
</div>
