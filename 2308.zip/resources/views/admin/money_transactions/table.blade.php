<div class=" table-responsive">     
    <table class="table table-hover">
        <th>#</th>
        <th>Mã giao dịch</th>
        <th>Trạng thái</th>
        <th style="min-width: 180px;">Tên tài khoản</th>
        <th style="min-width: 110px;">Loại</th>
        <th>Giá trị (đồng)</th>
        <th style="min-width: 110px;">Phương thức</th>
        <th style="min-width: 110px;">Giao dịch lúc</th>
        <th style="min-width: 100px;">Giao dịch bởi</th>
        @if (!in_array($classifies['record_status'], [1, 3]))
            <th style="min-width: 110px;">Xác nhận lúc</th>
            <th style="min-width: 100px;">Xác nhận bởi</th>
        @endif
        <th style="width: 100px;">Sự kiện</th>

        @foreach ($records as $record)
            <?php
                $tableCounter++;
                //
                if ($record->deleted_at) {
                    $destroyToggleLink = route($resourceRoutesAlias.'.destroy', $record->id);
                    $formDestroyToggleId = 'formDestroyToggle_'.$record->id;
                }
                else { 
                    $confirmLink = route($resourceRoutesAlias.'.confirm', $record->id);
                    $formConfirmId = 'formConfirm_'.$record->id;
                    //
                    if (! $record->confirmed_at) {
                        $editLink = route($resourceRoutesAlias.'.edit', $record->id);
                        $destroyToggleLink = route($resourceRoutesAlias.'.destroy', $record->id);
                        $formDestroyToggleId = 'formDestroyToggle_'.$record->id;
                    }
                }
            ?>
            @if (! $record->deleted_at && ! $record->confirmed_at)
                <tr title="Nhấn đúp để sửa" >
            @else 
                <tr>
            @endif
                <td>{{ $tableCounter }}</td>
                <td>
                    @if (! $record->deleted_at && ! $record->confirmed_at)
                        <a href="{{ $editLink }}">{{ 'GDT'.str_pad($record->id, 5, '0', STR_PAD_LEFT) }}</a>
                    @else {{ 'GDT'.str_pad($record->id, 5, '0', STR_PAD_LEFT) }} @endif
                </td>
                <td>
                    @if ($record->deleted_at) 
                        <span class="badge bg-dark">{{ $classifies['record_statuses'][2]->name }}</span>
                    @else
                        @if ($record->confirmed_at) 
                            <span class="badge bg-secondary">{{ $classifies['record_statuses'][1]->name }}</span>
                        @else
                            <span class="badge bg-success">{{ $classifies['record_statuses'][0]->name }}</span>
                        @endif
                    @endif
                </td>
                <td>{{ $record->user_name }}</td>
                <td>{{ $record->type_name }}</td>
                <td>{{ currency_format($record->cost) }}</td>
                <td>{{ $record->method_name }}</td>
                <td>{{ date("H:i d/m/Y", strtotime($record->created_at)) }}</td>
                <td>{{ $record->modified_name }}</td>
                @if (!in_array($classifies['record_status'], [1, 3]))
                    <td>{{ $record->confirmed_at ? date("H:i d/m/Y", strtotime($record->confirmed_at)) : '' }}</td>
                    <td>{{ $record->confirmed_name }}</td>
                @endif

                <!-- we will also add show, edit, and delete buttons -->
                @if ($classifies['record_status'] != 2)
                <td>
                    <div class="btn-group">
                        <button type="button" class="btn btn-skin btn-{{ $record->deleted_at ? 'dark' : $color->skin }} dropdown-toggle" data-toggle="dropdown"></button>
                        <div class="dropdown-menu">
                            @if ($record->deleted_at) 
                                <a href="#" class="dropdown-item btnDeleteToggle load-none" data-form-id="{{ $formDestroyToggleId }}" data-status="1"><i class="fas fa-trash-alt text-dark"></i> Khôi phục</a>
                            @else
                                @if (! $record->confirmed_at) 
                                    <a href="#" class="dropdown-item btnConfirm load-none" data-form-id="{{ $formConfirmId }}" data-status="2" data-type="{{ $record->type }}">
                                        @if ($record->type == 1)
                                            <i class="fas fa-check text-primary"></i> Xác nhận nộp tiền
                                        @else
                                            <i class="fas fa-check-double text-warning"></i> Xác nhận rút tiền
                                        @endif
                                    </a>
                                    <a href="{{ $editLink }}" class="dropdown-item edit"><i class="fas fa-edit text-info"></i> Sửa</a>
                                    <a href="#" class="dropdown-item btnDeleteToggle load-none" data-form-id="{{ $formDestroyToggleId }}" data-status="2"><i class="fas fa-trash-alt text-danger"></i> Xóa</a>
                                @else
                                    <a href="#" class="dropdown-item btnConfirm load-none" data-form-id="{{ $formConfirmId }}" data-status="1" data-type="{{ $record->type }}">
                                        @if ($record->type == 1)
                                            <i class="fas fa-check text-dark"></i> Hủy xác nhận nộp tiền
                                        @else
                                            <i class="fas fa-check-double text-dark"></i> Hủy xác nhận rút tiền
                                        @endif
                                    </a>
                                @endif
                            @endif
                        </div>
                    </div>

                    @if (! $record->deleted_at) 
                        <!-- Confirm Form -->
                        <form id="{{ $formConfirmId }}" action="{{ $confirmLink }}" method="POST" style="display: none;" class="hidden form-inline">
                            {{ csrf_field() }}
                            <input type="hidden" name="classifies" />
                        </form>
                    @endif
                    @if (! $record->confirmed_at) 
                        <!-- Disable/Enable Form -->
                        <form id="{{ $formDestroyToggleId }}" action="{{ $destroyToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                            {{ csrf_field() }}
                            {{ method_field('DELETE') }}
                            <input type="hidden" name="classifies" />
                        </form>
                    @endif
                </td>
                @endif
            </tr>
        @endforeach
        </tbody>
    </table>
</div>

{{ $record->confirmed_at }}
