<div id="default-status" class="col-md-9" data-default-contract-status="{{ get_default_contract_status() }}">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="user-id" class="form-control-label">Tên thành viên</label>
                <select id="user-id" name="user_id" class="form-control{{ $errors->has('user_id') ? ' is-invalid' : '' }}">
                    <option value="" {{ old('user_id', isset($record->user_id) ? $record->user_id : $classifies['user']) == '' ? 'selected' : '' }}>Hãy chọn thành viên</option>
                    @foreach ($classifies['users'] as $user)
                        <option value="{{ $user->id }}" {{ old('user_id', isset($record->user_id) ? $record->user_id : $classifies['user']) == $user->id ? 'selected' : '' }}>{{ $user->name }}</option>
                    @endforeach
                </select>
                @if ($errors->has('user_id'))
                    <div class="invalid-feedback">Tên thành viên {{ $errors->first('user_id') }}</div>
                @endif
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-6 -->
    </div>
    <!-- row -->
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="_cost" class="form-control-label">Trị giá (đồng)</i></label>
                <input id="_cost" type="text" class="form-control{{ $errors->has('cost') ? ' is-invalid' : '' }}" value="{{ old('cost', $record->cost) ? currency_format(old('cost', $record->cost)) : '' }}" required>
                <input id="cost" type="hidden" name="cost" value="{{ old('cost', $record->cost) }}">
                @if ($errors->has('cost'))
                    <div class="invalid-feedback">Giá trị {{ $errors->first('cost') }}</div>
                @endif
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-6 -->
        <div class="col-md-6">
            <div class="form-group">
                <label for="periods" class="form-control-label">Thời hạn (năm)</label>
                <select id="periods" name="periods" class="form-control{{ $errors->has('periods') ? ' is-invalid' : '' }}">
                    <option value="" {{ old('periods', $record->periods) == '' ? 'selected' : '' }}>Hãy chọn thời hạn</option>
                    @foreach ($classifies['periods'] as $period)
                        <option value="{{ $period->sub_id }}" {{ old('periods', $record->periods) == $period->sub_id ? 'selected' : '' }}>{{ $period->name }}</option>
                    @endforeach
                </select>
                @if ($errors->has('periods'))
                    <div class="invalid-feedback">Thời hạn {{ $errors->first('periods') }}</div>
                @endif
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-6 -->
    </div>
    <!-- row -->
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="opened-at" class="form-control-label">Ngày mở <i class="far fa-question-circle" title="Nếu không nhập sẽ chọn ngày hôm nay"></i></label>
                <div class="input-group date">
                    <?php
                        if(old('opened_at')){
                            $opened_at_value = date("d/m/Y", strtotime(old('opened_at')));
                        }
                        else if($record->id != ''){
                            $opened_at_value = date("d/m/Y", strtotime($record->opened_at));
                        }
                        else $opened_at_value = '';
                    ?>
                    <input id="opened-at" type="text" class="form-control{{ $errors->has('opened_at') ? ' is-invalid' : '' }}" name="opened_at" value="{{ $opened_at_value }}" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])/(?:0[1-9]|1[0-2]))|(30/(?:01|0[3-9]|1[0-2]))|(31/(?:0[13578]|1[02])))/((?:19|20)[0-9]{2})">
                    <span class="input-group-text input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
                @if ($errors->has('opened_at'))
                    <div class="invalid-feedback">Ngày mở {{ $errors->first('opened_at') }}</div>
                @endif
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-6 -->
        <div class="col-md-6">
            <div class="form-group">
                <label for="type" class="form-control-label">Loại <i class="far fa-question-circle" title="Nếu không chọn sẽ tự động chọn theo trị giá"></i></label>
                <select id="type" name="type" class="form-control{{ $errors->has('type') ? ' is-invalid' : '' }}">
                    <option value="" {{ old('type', $record->type) == '' ? 'selected' : '' }}>Hãy chọn loại</option>
                    @foreach ($classifies['types'] as $type)
                        <option value="{{ $type->sub_id }}" {{ old('type', $record->type) == $type->sub_id ? 'selected' : '' }}>{{ $type->name }}</option>
                    @endforeach
                </select>
                @if ($errors->has('type'))
                    <div class="invalid-feedback">Loại {{ $errors->first('type') }}</div>
                @endif
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-6 -->
    </div>
    <!-- row -->
</div>
<!-- /.col-md-9 -->
<input type="hidden" name="classifies" />