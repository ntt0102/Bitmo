<div class=" table-responsive">     
    <table class="table table-hover">
        <th>#</th>
        <th>ID</th>
        <th>Trạng thái</th>
        <th style="min-width: 180px;">Thành viên</th>
        <th style="min-width: 110px;">Loại</th>
        <th>Trị giá (đồng)</th>
        <th style="min-width: 100px;">Thời hạn (năm)</th>
        <th>Ngày mở HĐ</th>
        <th>Ngày đáo hạn</th>
        @if ($classifies['record_status'] != 3)
            <th style="min-width: 100px;">Ngày xác nhận mở</th>
            @if ($classifies['record_status'] != 1)
                <th>Ngày đóng HĐ</th>
                @if ($classifies['record_status'] != 4)
                    <th style="min-width: 100px;">Ngày xác nhận đóng</th>
                @endif
            @endif
        @endif
        <th>Cập nhật lúc</th>
        <th style="min-width: 100px;">Cập nhật bởi</th>
        @if (in_array($classifies['record_status'], [0, 2]))
            <th style="min-width: 100px;">Đã xóa lúc</th>
        @endif
        <th style="width: 100px;">Sự kiện</th>

        @foreach ($records as $record)
            <?php
            $tableCounter++;
            if (! $record->deleted_at) {
                if (! $record->open_confirmed_at) {
                    $openConfirmLink = route($resourceRoutesAlias.'.confirm.open', $record->id);
                    $formOpenConfirmId = 'formOpenConfirm_'.$record->id;
                }
                else if (! $record->closed_at){
                    $openConfirmLink = route($resourceRoutesAlias.'.confirm.open', $record->id);
                    $formOpenConfirmId = 'formOpenConfirm_'.$record->id;
                    //
                    $closeToggleLink = route($resourceRoutesAlias.'.close', $record->id);
                    $formCloseToggleId = 'formCloseToggle_'.$record->id;
                    //
                    $downloadPDFLink = route($resourceRoutesAlias.'.downloadPDF', $record->id);
                }
                else if (! $record->close_confirmed_at){
                    $closeToggleLink = route($resourceRoutesAlias.'.close', $record->id);
                    $formCloseToggleId = 'formCloseToggle_'.$record->id;
                    //
                    $closeConfirmLink = route($resourceRoutesAlias.'.confirm.close', $record->id);
                    $formCloseConfirmId = 'formCloseConfirm_'.$record->id;
                }
                else {
                    $closeConfirmLink = route($resourceRoutesAlias.'.confirm.close', $record->id);
                    $formCloseConfirmId = 'formCloseConfirm_'.$record->id;
                }
                //
                $editLink = route($resourceRoutesAlias.'.edit', $record->id);
            }
            //
            $destroyToggleLink = route($resourceRoutesAlias.'.destroy', $record->id);
            $formDestroyToggleId = 'formDestroyToggle_'.$record->id;
            
            ?>
            @if (! $record->deleted_at)
                <tr class="load" title="Nhấn đúp để sửa" >
            @else 
                <tr>
            @endif
                <td>{{ $tableCounter }}</td>
                <td>
                    @if (! $record->deleted_at)
                        <a href="{{ $editLink }}">{{ $record->id }}</a>
                    @else {{ $record->id }} @endif
                </td>
                <td>
                    @if ($record->deleted_at) 
                        <span class="badge bg-dark">{{ $classifies['record_statuses'][4]->name }}</span>
                    @else
                        @if (! $record->open_confirmed_at) 
                            <span class="badge bg-primary">{{ $classifies['record_statuses'][0]->name }}</span>
                        @else
                            @if (! $record->closed_at)
                                <span class="badge bg-success">{{ $classifies['record_statuses'][1]->name }}</span>
                            @else
                                @if (! $record->close_confirmed_at)
                                    <span class="badge bg-warning">{{ $classifies['record_statuses'][2]->name }}</span>
                                @else
                                    <span class="badge bg-secondary">{{ $classifies['record_statuses'][3]->name }}</span>
                                @endif
                            @endif
                        @endif
                    @endif
                </td>
                <td>{{ $record->user_name }}</td>
                <td>{{ $record->type_name }}</td>
                <td>{{ currency_format($record->cost) }}</td>
                <td>{{ $record->periods_name }}</td>
                <td>{{ date("d/m/Y", strtotime($record->opened_at)) }}</td>
                <td>{{ date("d/m/Y", strtotime($record->due_date)) }}</td>
                @if ($classifies['record_status'] != 3)
                    <td>{{ $record->open_confirmed_at ? date("d/m/Y", strtotime($record->open_confirmed_at)) : '' }}</td>
                    @if ($classifies['record_status'] != 1)
                        <td>{{ $record->closed_at ? date("d/m/Y", strtotime($record->closed_at)) : '' }}</td>
                        @if ($classifies['record_status'] != 4)
                            <td>{{ $record->close_confirmed_at ? date("d/m/Y", strtotime($record->close_confirmed_at)) : '' }}</td>
                        @endif
                    @endif
                @endif
                <td>{{ date("H:i d/m/Y", strtotime($record->updated_at)) }}</td>
                <td>{{ $record->modified_name }}</td>
                @if (in_array($classifies['record_status'], [0, 2]))
                    <td>{{ $record->deleted_at ? date("H:i d/m/Y", strtotime($record->deleted_at)) : ''}}</td>
                @endif

                <!-- we will also add show, edit, and delete buttons -->
                <td>
                    <div class="btn-group">
                        <button type="button" class="btn btn-skin btn-{{ $record->deleted_at ? 'dark' : $color->skin }} dropdown-toggle" data-toggle="dropdown"></button>
                        <div class="dropdown-menu">
                            @if (! $record->deleted_at)
                                @if (! $record->open_confirmed_at) 
                                    <a href="#" class="dropdown-item btnOpenConfirm load-none" data-form-id="{{ $formOpenConfirmId }}" data-status="2"><i class="fas fa-check text-primary"></i> Xác nhận mở</a>
                                @else
                                    @if (! $record->closed_at)
                                        <a href="#" class="dropdown-item btnOpenConfirm load-none" data-form-id="{{ $formOpenConfirmId }}" data-status="1"><i class="fas fa-check text-dark"></i> Hủy xác nhận mở</a>
                                        <a href="#" class="dropdown-item btnCloseToggle load-none" data-form-id="{{ $formCloseToggleId }}" data-status="2"><i class="fas fa-stop-circle text-success"></i> Đóng</a>
                                        <a href="{{ $downloadPDFLink }}" class="dropdown-item load-none"><i class="fas fa-download text-secondary"></i> Tải file PDF</a>
                                    @else
                                        @if (! $record->close_confirmed_at)
                                            <a href="#" class="dropdown-item btnCloseToggle load-none" data-form-id="{{ $formCloseToggleId }}" data-status="1"><i class="fas fa-stop-circle text-dark"></i> Hủy đóng</a>
                                            <a href="#" class="dropdown-item btnCloseConfirm load-none" data-form-id="{{ $formCloseConfirmId }}" data-status="2"><i class="fas fa-check-double text-warning"></i> Xác nhận đóng</a>
                                        @else
                                            <a href="#" class="dropdown-item btnCloseConfirm load-none" data-form-id="{{ $formCloseConfirmId }}" data-status="1"><i class="fas fa-check-double text-dark"></i> Hủy xác nhận đóng</a>
                                        @endif
                                    @endif
                                @endif
                                <a href="{{ $editLink }}" class="dropdown-item edit"><i class="fas fa-edit text-info"></i> Sửa</a>
                            @endif
                            <a href="#" class="dropdown-item btnDeleteToggle load-none" data-form-id="{{ $formDestroyToggleId }}" data-status="{{ $record->deleted_at ? '1' : '2'}}">
                                @if ($record->deleted_at)
                                    <i class="fas fa-window-restore text-dark"></i>
                                @else
                                    <i class="fas fa-trash-alt text-danger"></i>
                                @endif
                                {{ $record->deleted_at ? 'Khôi phục' : 'Xóa'}}
                            </a>
                        </div>
                    </div>
                    @if (! $record->deleted_at)
                        @if (! $record->open_confirmed_at) 
                            <!-- Open Confirm Contract Form -->
                            <form id="{{ $formOpenConfirmId }}" action="{{ $openConfirmLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                {{ csrf_field() }}
                                <input type="hidden" name="classifies" />
                            </form>
                        @else
                            @if (! $record->closed_at)
                                <!-- Open Confirm Contract Form -->
                                <form id="{{ $formOpenConfirmId }}" action="{{ $openConfirmLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="classifies" />
                                </form>
                                <!-- Close Contract Form -->
                                <form id="{{ $formCloseToggleId }}" action="{{ $closeToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="classifies" />
                                </form>
                            @else
                                @if (! $record->close_confirmed_at)
                                    <!-- Close Contract Form -->
                                    <form id="{{ $formCloseToggleId }}" action="{{ $closeToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                        {{ csrf_field() }}
                                        <input type="hidden" name="classifies" />
                                    </form>
                                    <!-- Close Confirm Contract Form -->
                                    <form id="{{ $formCloseConfirmId }}" action="{{ $closeConfirmLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                        {{ csrf_field() }}
                                        <input type="hidden" name="classifies" />
                                    </form>
                                @else
                                    <!-- Close Confirm Contract Form -->
                                    <form id="{{ $formCloseConfirmId }}" action="{{ $closeConfirmLink }}" method="POST" style="display: none;" class="hidden form-inline">
                                        {{ csrf_field() }}
                                        <input type="hidden" name="classifies" />
                                    </form>
                                @endif
                            @endif
                        @endif
                    @endif

                    <!-- Disable/Enable Record Form -->
                    <form id="{{ $formDestroyToggleId }}" action="{{ $destroyToggleLink }}" method="POST" style="display: none;" class="hidden form-inline">
                        {{ csrf_field() }}
                        {{ method_field('DELETE') }}
                        <input type="hidden" name="classifies" />
                    </form>
                </td>

            </tr>
        @endforeach
        </tbody>
    </table>
</div>
