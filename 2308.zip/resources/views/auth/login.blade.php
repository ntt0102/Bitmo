<?php
  $skin = get_color()->skin;
?>
@extends('layouts.frontend', ['skin' => $skin])

{{-- Page Title --}}
@section('page-title', 'Đăng nhập')

{{-- Main conten --}}
@section('content')
    <div class="login-box mb-0">
      <div class="card">
        <div class="card-body">
          <p class="box-msg">Đăng nhập để bắt đầu</p>
          <form method="POST" action="{{ route('login') }}">
            {{ csrf_field() }}
    
            <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="login" class="control-label">CMND hoặc Email</label>
                    <input id="login" type="text" class="form-control{{ $errors->has('username') || $errors->has('email') ? ' is-invalid' : '' }}" name="login" value="{{ old('username') ?: old('email') }}"  required autofocus>
                    <!--pattern="[0-9]{9}"-->
    
                    @if ($errors->has('username') || $errors->has('email'))
                      <span class="invalid-feedback">
                          <strong>{{ $errors->first('username') ?: $errors->first('email') }}</strong>
                      </span>
                    @endif
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- col-md-12 -->
            </div>
            <!-- row -->
            <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="password" class="control-label">Mật khẩu</label>
                    <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,32}" required >
    
                    @if ($errors->has('password'))
                      <span class="invalid-feedback">
                          <strong>{{ $errors->first('password') }}</strong>
                      </span>
                    @endif
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- col-md-12 -->
            </div>
            <!-- row -->
            <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="remember" name="remember" {{ old('remember') ? 'checked' : '' }}>
                      <label class="custom-control-label" for="remember">Ghi nhớ đăng nhập</label>
                    </div>
                    <!-- /.custom-control -->
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- col-md-12 -->
            </div>
            <!-- row -->
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <button type="submit" class="btn btn-{{ $skin }}">Đăng nhập</button>
                  </div>
                  <!-- /.form-group -->
              </div>
              <!-- col-md-6 -->
              <div class="col-md-6 mt-1">
                  <div class="form-group">
                      <a href="{{ route('password.request') }}" class="text-center">Quên mật khẩu</a>
                  </div>
                  <!-- /.form-group -->
              </div>
              <!-- col-md-6 -->
            </div>
            <!-- row -->
            <p class="box-msg"><em>Nếu bạn chưa có tài khoản hãy đăng ký tại <a href="{{ route('register') }}">đây</a></em></p>
          </form>
          <!-- /form -->
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->
    </div>   
    <!-- /.login-box -->
@endsection
