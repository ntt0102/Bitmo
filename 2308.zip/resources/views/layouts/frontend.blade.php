<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="robots" content="noindex, nofollow, noarchive">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }} @hasSection('page-title') | @yield('page-title') @endif</title>

        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
        <!-- Admin LTE -->
        <link rel="stylesheet" href="{{ asset('plugins/adminlte/adminlte.min.css') }}">
        <!-- Google Font: Source Sans Pro -->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,400i,700" rel="stylesheet">
        <!-- Layout -->
        <link rel="stylesheet" href="{{ asset('/dist/common/common.css') }}">
        <link rel="stylesheet" href="{{ asset('/dist/layouts/frontend.css') }}">

        @yield('head-extras')
    </head>

    <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
    <body class="hold-transition lockscreen">
        <!-- Loading -->
        <div id="loading" class="text-center text-{{ $skin }}">
            <i class="fas fa-cog fa-spin blue fa-4x"></i>
        </div>
        
        <!-- Site wrapper -->
        <div class="wrapper disabled">
            <!-- Header -->
            @includeIf('layouts.partials.frontend.header', ['skin' => $skin])
            <!-- Content -->
            <div class="pt-5 pb-4">
                @includeIf('flash::message')
                @yield('content')
            </div>
            <footer>
                <nav class="navbar fixed-bottom navbar-dark bg-{{ $skin }}">
                    <span class="col-md-10 offset-md-1 text-center"><b>Hỗ trợ: 01667.269.284 <i class="fas fa-phone-square"></i>   <i class="fab fa-facebook-square"></i></b></span>
                    <!-- <span class="col-md-1 text-right"><a href="#"><i class="fab fa-facebook-messenger"></i></a></span> -->
                </nav>
            </footer>

        </div>
        <!-- ./wrapper -->

        <!-- REQUIRED SCRIPTS -->
        <!-- jQuery -->
        <script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
        <!-- Bootstrap -->
        <script src="{{ asset('plugins/bootstrap/bootstrap.bundle.min.js') }}"></script>
        <!-- AdminLTE -->
        <script src="{{ asset('plugins/adminlte/adminlte.min.js') }}"></script>
        <!-- Common -->
        <script src="{{ asset('dist/common/common.js') }}"></script>
        
        <!-- OPTIONAL SCRIPTS -->
        <script src="{{ asset('dist/_partials/ajax/ajax.js') }}"></script>

        @yield('footer-extras')

        @stack('footer-scripts')
    </body>
</html>
