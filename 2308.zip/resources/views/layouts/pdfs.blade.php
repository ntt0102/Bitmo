<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>@yield('page-title')</title>
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
        <style type="text/css">
            
            .clearfix:after {
              content: "";
              display: table;
              clear: both;
            }

            a {
              color: #0087C3;
              text-decoration: none;
            }

            body {
              position: relative;
              width: 19.3cm;  
              height: 29.7cm; 
              margin: 0 0; 
              color: #555555;
              background: #FFFFFF;
              /*background: blue;*/
              font-size: 14px; 
              font-family: DejaVu Sans;
            }

            header {
              padding: 5px 0;
              margin-bottom: 20px;
              border-bottom: 1px solid #AAAAAA;
            }

            #logo {
              float: left;
              margin-top: 8px;
              color: #28a745;
              /*background: blue;*/
            }

            #logo i {
              float: left;
              line-height: .8;
              width: auto;
              margin-left: .8rem;
              margin-right: .5rem;
              margin-top: -3px;
              font-size: 80px;
              /*color: #28a745;*/
            }

            #logo div{
              font-weight: 300 !important;
              font-size: 18pt;
              margin-left: 13px; 
              margin-top: 55px; 
              margin-bottom: -10px;
              /*color: #28a745;*/
            }

            #company {
              float: right;
              text-align: right;
              padding-right: 218px;
              /*background: red;*/
            }

            h2.name {
              font-size: 1.4em;
              font-weight: normal;
              margin: 0;
            }
        </style>
    @yield('head-extras')
  </head>
  <body>
    <header class="clearfix">
      <div id="logo">
        <i class="fab fa-bimobject"></i>
        <div>{!! config('adminlte.logo-name') !!}</div>
      </div>
      <div id="company">
        <h2 class="name">Kênh Đầu Tư Bitmo</h2>
        <?php
          $admin = App\User::where('id', '=', 1)->get()->first();
        ?>
        <div>{{ $admin->residence }}</div>
        <div>{{ phone_format($admin->phone) }}</div>
        <div><a href="mailto:{{ $admin->email }}">{{ $admin->email }}</a></div>
      </div>
    </header>
    <main>
      @yield('content')
    </main>
  </body>
<!-- </html> -->
