<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-{{ $theme }}" data-theme="{{ $theme }}" data-skin="{{ $skin }}" data-url="{{ route('dashboard::settings.save') }}">
	
</aside>
<!-- /.control-sidebar -->