@extends('layouts.errors')

@section('title', 'Unauthorized')

@section('message', '401, Unauthorized.')
