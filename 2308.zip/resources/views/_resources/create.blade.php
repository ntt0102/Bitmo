<?php
  $color = get_color();
?>

{{-- Extends Layout --}}
@extends('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin])

<?php
    $_pageTitle = (isset($addVarsForView['_pageTitle']) && !empty($addVarsForView['_pageTitle']) ? $addVarsForView['_pageTitle'] : ucfirst($resourceTitle));
    $_pageSubtitle = (isset($addVarsForView['_pageSubtitle']) && !empty($addVarsForView['_pageSubtitle']) ? $addVarsForView['_pageSubtitle'] : "Thêm mới");
    $_formFiles = isset($addVarsForView['formFiles']) ? $addVarsForView['formFiles'] : false;
    $_listLink = route($resourceRoutesAlias.'.index');
    $_storeLink = route($resourceRoutesAlias.'.store');
?>

{{-- Breadcrumbs --}}
@section('breadcrumbs')
    {!! Breadcrumbs::render($resourceRoutesAlias.'.create') !!}
@endsection

{{-- Page Title --}}
@section('page-title', $_pageTitle)

{{-- Header Extras to be Included --}}
@section('head-extras')
    @includeIf($resourceAlias.'.header.form')
@endsection
    
@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card card-skin card-{{ $color->skin }} card-outline">
                <form class="form" role="form" method="POST" action="{{ $_storeLink }}" {{ $_formFiles === true ? 'enctype="multipart/form-data"' : ''}}>
                    {{ csrf_field() }}
                    {{ redirect_back_field() }}

                    <div class="card-header">
                        <h3 class="card-title col-md-6">&nbsp;<span class="d-none d-sm-inline-block">{{ $_pageSubtitle }}</span></h3>
                        <div class="card-tools">
                            <span id="btnList" data-link="{{ $_listLink }}" class="btn btn-sm btn-skin btn-{{ $color->skin }} mr-1">
                                <i class="fas fa-search"></i> <span>Danh sách</span>
                            </span>
                        </div>
                        <!-- /.card-tools -->
                    </div>
                    <!-- /.card-header -->   
                    <div class="card-body">   
                        <div class="row">
                            @includeIf($resourceAlias.'.form')
                        </div>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-skin btn-{{ $color->skin }}">
                                    <i class="fas fa-save"></i> <span>Lưu</span>
                                </button>
                                <span id="btnCancel" data-link="{{ $_listLink }}" class="btn btn-default ml-3 load">
                                    <i class="fas fa-ban"></i> <span>Hủy</span>
                                </span>
                            </div>
                            <!-- /.col-md-9 -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.card-footer -->
                </form>
                <!-- /form -->
            </div>
            <!-- /.card -->
        </div>
    </div>
@endsection

{{-- Footer Extras to be Included --}}
@section('footer-extras')
    @includeIf($resourceAlias.'.footer.form')
@endsection
