@extends('layouts.pdfs')

{{-- Page Title --}}
@section('page-title', 'HopDongSo'.$contract->id.'_'.date("H-i_d-m-Y", time()))

{{-- Header Extras to be Included --}}
@section('head-extras')
	<style type="text/css">

            #details {
              margin-bottom: 50px;
              padding-right: 187px;
            }

            #client {
              padding-left: 6px;
              border-left: 6px solid #28a745;;
              float: left;
            }

            #client .to {
              color: #777777;
            }

            #contract {
              float: right;
              text-align: right;
            }

            #contract h1 {
              color: #28a745;
              font-size: 2.0em;
              line-height: 1em;
              font-weight: normal;
              margin: 0  0 10px 0;
            }

            #contract .date {
              font-size: 1.1em;
              color: #777777;
            }

            table {
              width: 100%;
              border-collapse: collapse;
              border-spacing: 0;
              margin-bottom: 20px;
            }

              table td {
              padding: 20px;
              background: #EEEEEE;
              text-align: center;
              border: 1px solid #FFFFFF;
            }

            table td {
              text-align: right;
            }

            table td h3{
              /*color: #28a745;*/
              font-size: 1.2em;
              font-weight: bold;
              margin: 0 0 0.2em 0;
            }

            table .title {
              background: #DDDDDD;
              text-align: left;
            }

            table .value {
              background: #DDDDDD;
              font-size: 1.2em;

            }

            #notices{
              padding-left: 6px;
              border-left: 6px solid #28a745;;  
            }

            #notices .notice {
              font-size: 1.2em;
            }

            .break { 
                page-break-inside:avoid; 
                page-break-after:always; 
            }
        </style>
@endsection

@section('content')
	<div id="details" class="clearfix">
		<div id="client">
			<div class="to">KHÁCH HÀNG:</div>
			<h2 class="name">{{ $contract->user_name }}</h2> 
			<div class="address">{{ $contract->user_residence }}</div>
			<div>{{ phone_format($contract->user_phone) }}</div>
			<div class="email"><a href="mailto:{{ $contract->user_email }}">{{ $contract->user_email }}</a></div>
		</div>
		<div id="contract">
			<h1>BẢN HỢP ĐỒNG CHI TIẾT</h1>
			<div class="date">Ngày lập biên bản: {{ date("d/m/Y", time()) }}</div>
			<div class="date">Ngày hết hiệu lực: {{ date("d/m/Y", strtotime($contract->due_date)) }}</div>
		</div>
	</div>
	<table border="0" cellspacing="0" cellpadding="0">
		<tbody>
		  <tr>
		    <td class="title"><h3>Loại hợp đồng</h3></td>
		    <td class="value">{{ $contract->type_name }}</td>
		  </tr>
		  <tr>
		    <td class="title"><h3>Chu kỳ hợp đồng</h3></td>
		    <td class="value">{{ $contract->periods_name }} (năm)</td>
		  </tr>
		  <tr>
		    <td class="title"><h3>Lãi suất theo chu kỳ</h3></td>
		    <td class="value">{{ $contract->type_value }} (%)</td>
		  </tr>
		  <tr>
		    <td class="title"><h3>Trị giá hợp đồng</h3></td>
		    <td class="value">{{ currency_format($contract->cost, 1)}}</td>
		  </tr>
		  <tr>
		    <td class="title"><h3>Ngày mở hợp đồng</h3></td>
		    <td class="value">{{ date("d/m/Y", strtotime($contract->opened_at)) }}</td>
		  </tr>
		  <tr>
		    <td class="title"><h3>Ngày đáo hạn</h3></td>
		    <td class="value">{{ date("d/m/Y", strtotime($contract->due_date)) }}</td>
		  </tr>
		</tbody>
	</table>
	<div id="notices">
		<div>GHI CHÚ:</div>
		<div class="notice">- Hợp đồng có hiệu lực từ ngày mở hợp đồng.</div>
    <div class="notice">- Biên bản được tạo từ trang web của Bitmo và hợp lệ mà không cần chữ ký.</div>
	</div>
@endsection