<?php

namespace App\Http\Controllers\Admin;

use App\Models\Constant;
use App\Models\Classify;
// use App\Utils;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\Controllers\ResourceController;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;

class ConstantsController extends Controller
{
    use ResourceController;

    /**
     * @var string
     */
    protected $resourceAlias = 'admin.constants';

    /**
     * @var string
     */
    protected $resourceRoutesAlias = 'admin::constants';

    /**
     * Fully qualified class name
     *
     * @var string
     */
    protected $resourceModel = Constant::class;

    /**
     * @var string
     */
    protected $resourceTitle = 'Định danh';

    /**
     * Used to validate store.
     *
     * @return array
     */
    private function resourceStoreValidationData(Request $request = null)
    {
        return [
            'rules' => [
                'name' => 'required|string|max:191',
                'value' => 'required|string|max:191',
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * Used to validate update.
     *
     * @param $record
     * @return array
     */
    private function resourceUpdateValidationData($record, Request $request = null)
    {
        return [
            'rules' => [
                'name' => 'required|string|max:191',
                'value' => 'required|string|max:191',
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param null $record
     * @return array
     */
    private function getValuesToSave(Request $request, $record = null)
    {
        $creating = is_null($record);
        $values = [];
        $values['name'] = $request->input('name', '');
        $values['value'] = $request->input('value', '');
        $values['is_array'] = $request->input('is_array') ? 1 : 0;
        $values['modified_by'] = Auth::user()->id;
        
        return $values;
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = $this->getResourceModel()::where('constants.id', '>', 0);
        $record_status = $request->input('record-status', '');
        // Filter by Search
        if (! empty($search)) {
            $records = $records->where(function($query) use ($search){
                $query->orWhere('constants.id', 'LIKE', '%'.$search.'%');
                $query->orWhere('constants.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('constants.value', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Record Status Select
        if (! empty($record_status)) {
            $default_record_status = get_default_record_status();

            if($record_status == $default_record_status)
                $records = $records->whereNull('constants.deleted_at');
            if($record_status && $record_status != $default_record_status)
                $records = $records->whereNotNull('constants.deleted_at');
        }
        //
        return $records->leftjoin('users as modified', 'modified.id', '=', 'constants.modified_by')
                        ->select('constants.*',
                            DB::raw('SUBSTRING_INDEX(modified.name, " ", -1) AS modified_name')
                        )
                        ->orderBy('constants.name', 'asc')
                        ->paginate($show);
    }
    
    /**
     * @param \Illuminate\Http\Request $request
     * @param array $classifies
     * @return array
     */
    private function getFilterClassifies(Request $request = null)
    {
        $classifies['record_statuses'] = Classify::where('group', '=', 1)
                                                ->where('sub_id', '<', 3)
                                                ->whereNull('deleted_at')
                                                ->orderBy('display_no', 'asc')->get();
        if(! empty($request)){
            $classifies['record_status'] = $request->input('record-status');
        }
        return $classifies;
    }

}
