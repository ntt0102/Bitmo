<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Log;
use App\Models\Classify;
use App\Models\Constant;
use Illuminate\Support\Facades\DB;

class LogsController extends Controller
{
    /**
     * Show the user's profile.
     *
     * @return Response
     */
    public function showLog(Request $request)
    {
        $paginatorData = [];
        $show = (int) $request->input('show', '');
        $show = (is_numeric($show) && $show > 0 && $show <= 100) ? $show : 10;
        if ($show != 10) {
            $paginatorData['show'] = $show;
        }
        $search = trim($request->input('search', ''));
        if (! empty($search)) {
            $paginatorData['search'] = $search;
        }
        $records = $this->getSearchRecords($request, $show, $search);
        $records->appends($paginatorData);
        //
        $classifies = $this->getClassifies($request);

        return view('admin.logs.index', [
            'records' => $records,
            'search' => $search,
            'classifies' => $classifies,
        ]);
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = Log::leftjoin('users as modified', 'modified.id', '=', 'logs.modified_by');
        $records->leftjoin('classifies as type', function($join) {
            $join->on('type.group', '=', DB::raw('9'));
            $join->on('type.sub_id', '=', 'logs.type');
        });
        $records->leftjoin('classifies as table', function($join) {
            $join->on('table.group', '=', DB::raw('14'));
            $join->on('table.value', '=', 'logs.table');
        });
        $records->leftjoin('classifies as action', function($join) {
            $join->on('action.group', '=', DB::raw('15'));
            $join->on('action.value', '=', 'logs.action');
        });
        $records->select('logs.*',
            'type.name as type_name',
            'table.name as table_name',
            'action.name as action_name',
            DB::raw('SUBSTRING_INDEX(modified.name, " ", -1) AS modified_name')
        );
        // Filter by Search
        if (! empty($search)) {
            $records = $records->where(function($query) use ($search){
                $query->orWhere('logs.id', 'LIKE', '%'.$search.'%');
                $query->orWhere('logs.table', 'LIKE', '%'.$search.'%');
                $query->orWhere('logs.action', 'LIKE', '%'.$search.'%');
                $query->orWhere('logs.is_error', 'LIKE', '%'.$search.'%');
                $query->orWhere('logs.note', 'LIKE', '%'.$search.'%');
                $query->orWhere('modified.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('type.name', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Type of Log Select
        $type = $request->input('type', '');
        if (! empty($type)) {
            $records = $records->where('logs.type', '=', $type);
        }
        // Filter by Interval Select
        $interval = $request->input('interval', '');
        if (! empty($interval)) {
            list($period, $unit) = explode("-", $interval);
            $unit = Classify::where('group', '=', 11)->where('sub_id', '=', $unit)
                                ->whereNull('deleted_at')->get()->first();
            $unit = $unit ? $unit->value : '1 DAY';
            //
            $sql = 'logs.created_at >= SUBDATE(NOW(), INTERVAL '.$period.'*'.$unit.')';
        }
        else $sql = 'logs.created_at < NOW()';
        $records->whereRaw($sql);
        //
        $records->orderBy('logs.created_at', 'desc');
        return $records->paginate($show);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param array $classifies
     * @return array
     */
    private function getClassifies(Request $request = null)
    {
        $classifies['types'] = Classify::where('group', '=', 9)
                                                ->whereNull('deleted_at')
                                                ->orderBy('display_no', 'asc')->get();
        $classifies['time_periods'] = Constant::where('id', '=', 10)->whereNull('deleted_at')->get()->first()->value;
        $classifies['time_units'] = Classify::where('group', '=', 11)
                                                ->whereNull('deleted_at')
                                                ->orderBy('display_no', 'asc')->get();
        if(! empty($request)){
            $classifies['type'] = $request->input('type');
            $classifies['interval'] = $request->input('interval');
        }
        return $classifies;
    }
}
