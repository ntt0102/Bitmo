<?php

namespace App\Http\Controllers\Admin;

use App\Models\Contract;
use App\Models\Classify;
use App\Models\Constant;
use App\User;
use App\Utils;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\Controllers\ResourceController;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use PDF;
use View;
use App\Notifications\OpenedContractNotification;
use App\Notifications\ClosedContractNotification;
use App\Notifications\OpenConfirmedContractNotification;
use App\Notifications\CloseConfirmedContractNotification;
use Illuminate\Support\Facades\Notification;

class ContractsController extends Controller
{
    use ResourceController;
    
    /**
     * @var string
     */
    protected $resourceAlias = 'admin.contracts';

    /**
     * @var string
     */
    protected $resourceRoutesAlias = 'admin::contracts';

    /**
     * Fully qualified class name
     *
     * @var string
     */
    protected $resourceModel = Contract::class;

    /**
     * @var string
     */
    protected $resourceTitle = 'Hợp đồng';

    /**
     * Used to validate store.
     *
     * @return array
     */
    private function resourceStoreValidationData(Request $request = null)
    {
        return [
            'rules' => [
                'user_id' => 'required',
                'opened_at' => 'nullable',
                'type' => 'nullable',
                'cost' => 'required|numeric|min:1000000',
                'periods' => 'required',
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * Used to validate update.
     *
     * @param $record
     * @return array
     */
    private function resourceUpdateValidationData($record, Request $request = null)
    {
        return [
            'rules' => [
                'user_id' => 'required',
                'opened_at' => 'nullable',
                'type' => 'nullable',
                'cost' => 'required|numeric|min:1000000',
                'periods' => 'required',
            ],
            'messages' => [],
            'attributes' => [],
        ];
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param null $record
     * @return array
     */
    private function getValuesToSave(Request $request, $record = null)
    {
        $creating = is_null($record);
        $values = [];
        $values['user_id'] = $request->input('user_id', '');
        $values['opened_at'] = $request->input('opened_at', '') ? Carbon::createFromFormat('d/m/Y', $request->input('opened_at', '')) : Carbon::now();
        //
        $limit = Constant::where('id', '=', 8)->whereNull('deleted_at')->get()->first()->value;
        $values['type'] = $request->input('type', '') ? $request->input('type', '') : ($request->input('cost', '') < $limit ? 1 : 2);
        //
        $values['cost'] = $request->input('cost', '');
        $values['periods'] = $request->input('periods', '');
        $values['modified_by'] = Auth::user()->id;

        return $values;
    }

    /**
     * @param $record
     */
    private function doStoreSuccess($record = null)
    {
        if($record){
            $users = User::where('is_admin', '=', 1)->whereNull('deleted_at')->get();
            //send notify
            Notification::send($users, new OpenedContractNotification($record));
        }
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = $this->getResourceModel()::leftjoin('users', 'users.id', '=', 'contracts.user_id');
        $records->leftjoin('users as modified', 'modified.id', '=', 'contracts.modified_by');
        $records->leftjoin('classifies as type', function($join){
            $join->on('type.group', '=', DB::raw('3'));
            $join->on('type.sub_id', '=', 'contracts.type');
        });
        $records->leftjoin('classifies as periods', function($join){
            $join->on('periods.group', '=', DB::raw('4'));
            $join->on('periods.value', '=', 'contracts.periods');
        });
        $records->select('contracts.*',
            'users.name as user_name',
            'type.name as type_name',
            'periods.name as periods_name',
            DB::raw('DATE_ADD(contracts.opened_at, INTERVAL contracts.periods YEAR) AS due_date'),
            DB::raw('(CASE WHEN contracts.open_confirmed_at IS NULL THEN NOW() ELSE contracts.open_confirmed_at END) AS open_confirmed_date'),
            DB::raw('(CASE WHEN contracts.closed_at IS NULL THEN NOW() ELSE contracts.closed_at END) AS closed_date'),
            DB::raw('(CASE WHEN contracts.close_confirmed_at IS NULL THEN NOW() ELSE contracts.close_confirmed_at END) AS close_confirmed_date'),
            DB::raw('SUBSTRING_INDEX(modified.name, " ", -1) AS modified_name')
        );
        // Filter by Id
        $id = $request->input('id', '');
        if (! empty($id)) {
            $records->where('contracts.id', '=', $id);
        }
        // Filter by Search
        if (! empty($search)) {
            $records->where(function($query) use ($search){
                $query->orWhere('contracts.id', 'LIKE', '%'.$search.'%');
                $query->orWhere('contracts.cost', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.username', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.residence', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.phone', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.email', 'LIKE', '%'.$search.'%');
                $query->orWhere('users.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('type.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('periods.name', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Contract Status
        $record_status = $request->input('record-status', '');
        if (! empty($record_status)) {
            if($record_status == 2)
                $records->whereNotNull('contracts.deleted_at');
            else {
                $records->whereNull('contracts.deleted_at');
                if($record_status == 3)
                    $records->whereNull('contracts.open_confirmed_at');
                else{
                    $records->whereNotNull('contracts.open_confirmed_at');
                    if($record_status == 1)
                        $records->whereNull('contracts.closed_at');
                    else {
                        $records->whereNotNull('contracts.closed_at');
                        if($record_status == 4)
                            $records->whereNull('contracts.close_confirmed_at');
                        if($record_status == 5)
                            $records->whereNotNull('contracts.close_confirmed_at');
                    }
                }
            }
        }
        // Order by
        $order_by = $request->input('order-by', '');
        if (! empty($order_by)) {
            list($_by, $_order) = explode("-", $order_by);
            // Order
            $order = Classify::where('group', '=', 5)->where('sub_id', '=', $_order)
                                ->whereNull('deleted_at')->get()->first();
            $order = $order ? $order->value : 'desc';
            // By
            $by = Classify::where('group', '=', 6)->where('sub_id', '=', $_by)
                                ->whereNull('deleted_at')->get()->first();
            $by = $by ? $by->value : 'contracts.id';
            // $by = $by->value;
        }
        else {
            $by = 'contracts.id';
            $order = 'desc';
        }
        $records->orderBy($by, $order);
        //
        return $records->paginate($show);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param array $classifies
     * @return array
     */
    private function getFilterClassifies(Request $request = null)
    {
        $classifies['record_statuses'] = Classify::where('group', '=', 1)
                                                ->whereNull('deleted_at')
                                                ->orderBy('display_no', 'asc')->get();
        $classifies['bys'] = Classify::where('group', '=', 6)
                                                    ->whereNull('deleted_at')
                                                    ->orderBy('display_no', 'asc')->get();
        $classifies['orders'] = Classify::where('group', '=', 5)
                                                    ->whereNull('deleted_at')
                                                    ->orderBy('display_no', 'asc')->get();
        //
        if(! empty($request)){
            $classifies['record_status'] = $request->input('record-status');
            $classifies['order_by'] = $request->input('order-by');
        }
        return $classifies;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param array $classifies
     * @return array
     */
    private function getFormClassifies(Request $request = null)
    {
        $classifies['users'] = User::whereNull('deleted_at')
                                    ->orderBy('name', 'asc')->get();
        $classifies['types'] = Classify::where('group', '=', 3)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();
        $classifies['periods'] = Classify::where('group', '=', 4)
                                        ->whereNull('deleted_at')
                                        ->orderBy('display_no', 'asc')->get();

        if(! empty($request)){
            $classifies['user'] = $request->input('user');
        }                                        
        return $classifies;
    }

    /**
     * Close or Cancel the contract.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function close(Request $request, $id)
    {
        $record = $this->getResourceModel()::findOrFail($id);

        $valuesToSave['modified_by'] = Auth::user()->id;
        if ($record->closed_at){
            $valuesToSave['closed_at'] = null;
            $title = 'Hủy đóng';
            $type = 4;
        }
        else {
            $valuesToSave['closed_at'] = Carbon::now();
            $title = 'Đóng';
            $type = 2;
        }
        //
        if ($record->update($valuesToSave)) {
            flash()->success($title.' thành công.');
            $is_error = 0;
            //
            //send notify
            if ($record->closed_at) {
                $users = User::where('is_admin', '=', 1)->whereNull('deleted_at')->get();
                Notification::send($users, new ClosedContractNotification($record));
            }
        } else {
            flash()->info($title.' thất bại.');
            $is_error = 1;
        }
        //
        list(, $table) = explode("::", $this->getResourceRoutesAlias());
        Utils::writeLog($type, $table, $is_error);
        //
        $urlParameter =  $request->input('classifies', '');
        return redirect(route($this->getResourceRoutesAlias().'.index').'?'.$urlParameter);
    }

    /**
     * Open Confirm the contract.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function openConfirm(Request $request, $id)
    {
        $record = $this->getResourceModel()::findOrFail($id);
        $notification_id = $request->input('notification_id', '');

        $valuesToSave['modified_by'] = Auth::user()->id;
        if ($record->open_confirmed_at){
            if($notification_id){
                flash()->info('Đã được xác nhận bởi quản trị viên khác.');
            }
            else {
                $valuesToSave['open_confirmed_at'] = null;
                $title = 'Hủy xác nhận mở';
            }
            $type = 4;
        }
        else {
            $valuesToSave['open_confirmed_at'] = Carbon::now();
            $title = 'Xác nhận mở';
            $type = 2;
        }
        //
        if(! ($notification_id && $type == 4)){
            if ($record->update($valuesToSave)) {
                flash()->success($title.' thành công.');
                $is_error = 0;
                //
                //send notify
                if ($record->open_confirmed_at) {
                    $user = User::find($record->user_id);
                    Notification::send($user, new OpenConfirmedContractNotification($record));
                }
            } else {
                flash()->info($title.' thất bại.');
                $is_error = 1;
            }
            //
            list(, $table) = explode("::", $this->getResourceRoutesAlias());
            Utils::writeLog($type, $table, $is_error);
        }
        //
        $urlParameter =  $request->input('classifies', '');
        if($notification_id){
            foreach (Auth::user()->unreadNotifications as $notification) {
                if($notification->id == $notification_id) {
                    $notification->markAsRead();
                }
            }
            return redirect($urlParameter);
        }
        return redirect(route($this->getResourceRoutesAlias().'.index').'?'.$urlParameter);
    }

    /**
     * Close Confirm the contract.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function closeConfirm(Request $request, $id)
    {
        $record = $this->getResourceModel()::findOrFail($id);
        $notification_id = $request->input('notification_id', '');

        $valuesToSave['modified_by'] = Auth::user()->id;
        if ($record->close_confirmed_at){
            if($notification_id){
                flash()->info('Đã được xác nhận bởi quản trị viên khác.');
            }
            else {
                $valuesToSave['close_confirmed_at'] = null;
                $title = 'Hủy xác nhận đóng';
            }
            $type = 4;
        }
        else {
            $valuesToSave['close_confirmed_at'] = Carbon::now();
            $title = 'Xác nhận đóng';
            $type = 2;
        }
        //
        if(! ($notification_id && $type == 4)){
            if ($record->update($valuesToSave)) {
                flash()->success($title.' thành công.');
                $is_error = 0;
                //
                //send notify
                if ($record->close_confirmed_at) {
                    $user = User::find($record->user_id);
                    Notification::send($user, new CloseConfirmedContractNotification($record));
                }
            } else {
                flash()->info($title.' thất bại.');
                $is_error = 1;
            }
            //
            list(, $table) = explode("::", $this->getResourceRoutesAlias());
            Utils::writeLog($type, $table, $is_error);
        }
        //
        $urlParameter =  $request->input('classifies', '');
        if($notification_id){
            foreach (Auth::user()->unreadNotifications as $notification) {
                if($notification->id == $notification_id) {
                    $notification->markAsRead();
                }
            }
            return redirect($urlParameter);
        }
        return redirect(route($this->getResourceRoutesAlias().'.index').'?'.$urlParameter);
    }

    /**
     * Download PDF file of the contract.
     *
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function downloadPDF($id){
        $fileName = 'HopDongSo'.$id.'_'.date("H-i_d-m-Y", time());
        $contract = $this->getResourceModel()::where('contracts.id', '=', $id)
        ->leftjoin('users', 'users.id', '=', 'contracts.user_id')
        ->leftjoin('classifies as type', function($join)
            {
                $join->on('type.group', '=', DB::raw('3'));
                $join->on('type.sub_id', '=', 'contracts.type');
            })
        ->leftjoin('classifies as periods', function($join)
            {
                $join->on('periods.group', '=', DB::raw('4'));
                $join->on('periods.value', '=', 'contracts.periods');
            })
        ->select('contracts.*',
            'users.name as user_name',
            'users.residence as user_residence',
            'users.phone as user_phone',
            'users.email as user_email',
            'type.name as type_name',
            'type.value as type_value',
            'periods.name as periods_name',
            DB::raw('DATE_ADD(contracts.opened_at, INTERVAL contracts.periods YEAR) AS due_date')
        )->get()->first();

        $view1 = View::make('pdfs.contract', compact('contract'))->render();
        // $view2 = View::make('pdfs.contract', compact('contract'))->render();

        $pdf = PDF::setOptions([
            'logOutputFile' => storage_path('logs/log.htm'),
            'tempDir' => storage_path('logs/')
        ])
        ->loadView('pdfs.contract', compact('contract'));
        // ->loadHTML($view1 . $view2);
        return $pdf->download($fileName.'.pdf');
       // return view('pdfs.contract', compact('contract'));

    }
}
