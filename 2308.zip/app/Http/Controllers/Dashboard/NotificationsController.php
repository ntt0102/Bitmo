<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Classify;
use App\Models\Constant;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use View;

class NotificationsController extends Controller
{
    /**
     * Show the notifications.
     *
     * @return Response
     */
    public function showNotifications(Request $request)
    {
        $paginatorData = [];
        $show = (int) $request->input('show', '');
        $show = (is_numeric($show) && $show > 0 && $show <= 100) ? $show : 10;
        if ($show != 10) {
            $paginatorData['show'] = $show;
        }
        $search = trim($request->input('search', ''));
        if (! empty($search)) {
            $paginatorData['search'] = $search;
        }
        $records = $this->getSearchRecords($request, $show, $search);
        $records->appends($paginatorData);
        //
        $classifies = $this->getClassifies($request);

        return view('dashboard.notifications.index', [
            'records' => $records,
            'search' => $search,
            'classifies' => $classifies,
        ]);
        // return view('welcome');
    }

    /**
     * Retrieve the list of the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $show
     * @param string|null $search
     * @return \Illuminate\Support\Collection
     */
    private function getSearchRecords(Request $request, $show = 15, $search = null)
    {
        $records = Notification::where('notifications.notifiable_id', '=', Auth::user()->id);
        // $records->leftjoin('users as sender', 'sender.id', '=', 'notifications.notifiable_id');
        $records->leftjoin('classifies as type', function($join) {
            $join->on('type.group', '=', DB::raw('12'));
            $join->on('type.value', '=', 'notifications.type');
        });
        $records->select('notifications.*',
            'type.sub_id as type_sub_id',
            'type.name as type_name',
            // 'sender.name as sent_user',
            'notifications.id as notification_id'
            // DB::raw('SUBDATE(NOW(), INTERVAL '.$interval.') AS interval_date')
        );
        // Filter by Id
        $id = $request->input('id', '');
        if (! empty($id)) {
            $records->where('notifications.id', '=', $id);
            //
            if($records->get()->first()->type_sub_id > 3) {
                foreach (Auth::user()->unreadNotifications as $notification) {
                    if($notification->id == $id) {
                        $notification->markAsRead();
                    }
                }
            }
        }
        // Filter by Search
        if (! empty($search)) {
            $records->where(function($query) use ($search){
                $query->orWhere('notifications.id', 'LIKE', '%'.$search.'%');
                $query->orWhere('type.name', 'LIKE', '%'.$search.'%');
                $query->orWhere('sender.name', 'LIKE', '%'.$search.'%');
             });
        }
        // Filter by Type of Notification Select
        $type = $request->input('type', '');
        if (! empty($type)) {
            $records->where('type.sub_id', '=', $type);
        }
        // Filter by Status of Notification Select
        $status = $request->input('status', '');
        if (! empty($status)) {
            if($status == 1)
                $records->whereNull('notifications.read_at');
            if($status && $status != 1)
                $records->whereNotNull('notifications.read_at');
        }
        // Filter by Interval Select
        $interval = $request->input('interval', '');
        if (! empty($interval)) {
            list($period, $unit) = explode("-", $interval);
            $unit = Classify::where('group', '=', 11)->where('sub_id', '=', $unit)
                                ->whereNull('deleted_at')->get()->first();
            $unit = $unit ? $unit->value : '1 DAY';
            //
            $sql = 'notifications.created_at >= SUBDATE(NOW(), INTERVAL '.$period.'*'.$unit.')';
        }
        else $sql = 'notifications.created_at < NOW()';
        $records->whereRaw($sql);
        //
        $records->orderBy('notifications.created_at', 'desc');
        return $records->paginate($show);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param array $classifies
     * @return array
     */
    private function getClassifies(Request $request = null)
    {
        $loginer_admin = Auth::user()->is_admin;
    	$classifies['statuses'] = Classify::where('group', '=', $loginer_admin ? 13 : 16)
            ->whereNull('deleted_at')
            ->orderBy('display_no', 'asc')->get();
        $classifies['types'] = Classify::where('group', '=', 12)
            ->where('sub_id', '>', 3*(1-$loginer_admin))
            ->whereNull('deleted_at')
            ->orderBy('display_no', 'asc')->get();
        $classifies['time_periods'] = Constant::where('id', '=', 10)->whereNull('deleted_at')->get()->first()->value;
        $classifies['time_units'] = Classify::where('group', '=', 11)
            ->whereNull('deleted_at')
            ->orderBy('display_no', 'asc')->get();
        if(! empty($request)){
        	$classifies['status'] = $request->input('status');
            $classifies['type'] = $request->input('type');
            $classifies['interval'] = $request->input('interval');
        }
        return $classifies;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return Response
     */
    public function markAsReadAll(Request $request)
    {
        Auth::user()->unreadNotifications->markAsRead();
        $urlParameter =  $request->input('classifies', '');
        return redirect($urlParameter);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param $id
     * @return Response
     */
    public function markAsRead(Request $request, $id)
    {
        foreach (Auth::user()->unreadNotifications as $notification) {
            if($notification->id == $id) {
                $notification->markAsRead();
            }
        }
        //
        $urlParameter =  $request->input('classifies', '');
        return redirect($urlParameter);
    }

    /**
     * Get interval unread notificatios.
     *
     * @param  Request  $request
     * @return Response
     */
    public function getIntervals(Request $request)
    {
        // $notifications = \App\Utils::getNotifications();
        // $view = View::make('layouts.partials.backend.notifications', compact('notifications'))->render();
        $intervals = [];
        foreach (Auth::user()->unreadNotifications as $notification) {
            array_push($intervals, get_interval($notification->created_at));
        }
        //
        return response()->json($intervals);
    }
}
