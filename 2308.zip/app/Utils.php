<?php

namespace App;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Models\Log;
use Carbon\Carbon;
use App\Models\Notification;
use Illuminate\Support\Facades\DB;
use App\Models\GroupMember;

final class Utils
{
    /**
     * @param array|string $routes
     * @return bool
     */
    public static function checkRoute($routes)
    {
        if (is_string($routes)) {
            return Route::currentRouteName() == $routes;
        } elseif (is_array($routes)) {
            return in_array(Route::currentRouteName(), $routes);
        }

        return false;
    }

    /**
     * @param null $guard
     * @return string
     */
    public static function getUserRoleLabel($guard = null)
    {
        if (! Auth::guard($guard)->guest()) {
            $user = Auth::guard($guard)->user();
            if ($user->isAdmin()) {
                return 'Quản trị viên';//'Administrator';
            } else {
                return 'Thành viên';//'Member';
            }
        }

        return 'Khách vãng lai';//'Anonymous';
    }

    /**
     * @param $type
     * @param $table
     * @param $is_error
     * @param null $action
     * @param null $note
     */
    public static function writeLog($type, $table, $is_error, $action = null, $note = null)
    {
        $values['type'] = $type;
        $values['table'] = $table;
        $values['action'] = $action ? $action : Route::currentRouteName();
        $values['is_error'] = $is_error;
        $values['note'] = $note ? $note : '';
        $values['created_at'] = Carbon::now();
        $values['modified_by'] = Auth::guard()->guest() ? 0 : Auth::user()->id;
        Log::create($values);
    }

    /**
     * @return array
     */
    public static function getNotifications()
    {
        $notifications = Notification::where('notifications.notifiable_id', '=', Auth::user()->id);
        $notifications->whereNull('notifications.read_at');
        $notifications->leftjoin('classifies as type', function($join) {
            $join->on('type.group', '=', DB::raw('12'));
            $join->on('type.value', '=', 'notifications.type');
        });
        $notifications->select('notifications.*',
            'type.sub_id as type_sub_id',
            'type.name as type_name',
            'notifications.id as notification_id'
        );
        $notifications->orderBy('notifications.created_at', 'desc');
        $notifications = $notifications->get();
        //
        return $notifications;
    }

    /**
     * @return array
     */
    public static function getMessages()
    {
        $sql =  "SELECT  a.*, b.unread_count, ";
        $sql .= "        (SELECT COUNT(*) FROM messages WHERE receiver_id = :user_id AND read_at IS NULL AND deleted_at IS NULL) AS total ";
        $sql .= "FROM ( ";
        $sql .= "    SELECT * FROM messages WHERE receiver_id = :user_id AND read_at IS NULL AND deleted_at IS NULL ";
        $sql .= ") a ";
        $sql .= "INNER JOIN ( ";
        $sql .= "    SELECT  c.sender_id, MAX(c.created_at) mxdate, SUM(CASE WHEN c.read_at IS NULL THEN 1 ELSE 0 END) AS unread_count ";
        $sql .= "    FROM ( ";
        $sql .= "        SELECT * FROM messages WHERE receiver_id = :user_id AND read_at IS NULL AND deleted_at IS NULL ";
        $sql .= "    ) c ";
        $sql .= "    GROUP BY c.sender_id ";
        $sql .= ") b ON a.sender_id = b.sender_id AND a.created_at = b.mxdate ";
        $sql .= "ORDER BY a.created_at DESC ";
        //
        $results = DB::select($sql, ['user_id' => Auth::user()->id]);
        return $results;
    }

    /**
     *
     * @param $contacter_id
     * @return $message
     */
    public static function getLatestMessage($user_id, $receiver_id)
    {
        if (! empty($user_id) && ! empty($receiver_id)) {
            $sql =  "SELECT * ";
            $sql .= "FROM messages  ";
            $sql .= "WHERE ((sender_id = :user_id AND receiver_id = :receiver_id) OR (sender_id = :receiver_id AND receiver_id = :user_id)) ";
            $sql .= "AND deleted_at IS NULL ";
            $sql .= "ORDER BY created_at DESC ";
            $sql .= "LIMIT 1 ";
            //
            $message = collect(DB::select($sql, ['user_id' => $user_id, 'receiver_id' => $receiver_id]))->first();
            return $message;
        }
        else return NULL;
    }

    /**
     *
     * @param $group
     * @param $user_id
     */
    public static function addGroupMember($group, $user_id)
    {
        if (! empty($group) && ! empty($user_id)) {
            $member = GroupMember::where('group', '=', $group)->where('user_id', '=', $user_id)->get()->first();
            if(!$member){
                GroupMember::create([
                    'group' => $group,
                    'user_id' => $user_id,
                    'modified_by' => Auth::guest() ? $user_id : Auth::user()->id
                ]);
            }
            
        }
    }

    /**
     *
     * @param $group
     * @param $user_id
     */
    public static function destroyGroupMember($group, $user_id)
    {
        if (! empty($group) && ! empty($user_id)) {
            $member = GroupMember::where('group', '=', $group)->where('user_id', '=', $user_id)->get()->first();
            if($member) $member->delete();
        }
    }
}
