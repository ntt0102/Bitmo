<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Classify extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'classifies';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'group', 'sub_id', 'value', 'name', 'display_no', 'deleted_at', 'modified_by'
    ];
    
    /**
     * Get the modified user.
     */
    // public function modified_user()
    // {
    //     return $this->belongsTo('App\User', 'modified_by');
    // }
}