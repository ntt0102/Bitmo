<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MoneyTransaction extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'money_transactions';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'type', 'cost', 'method', 'confirmed_at', 'confirmed_by', 'deleted_at', 'modified_by'
    ];   
}
