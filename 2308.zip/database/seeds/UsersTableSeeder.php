<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            [
                'name' => 'Nguyễn Trường Thọ',
                'username' => '205618994',
                'password' => Hash::make('Bitmo123'),
                'gender' => 2,
                'birthday' => Carbon::createFromFormat('d/m/Y', '01/02/1992'),
                'residence' => 'Thôn 4, Quế Thuận, Quế Sơn, Quảng Nam',
                'phone' => '01667269284',
                'email' => 'ntt0102@gmail.com',
                'is_admin' => 1,
                'avatar' => config('adminlte.avatar-male'),
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => null,
            ],
            [
                'name' => 'Dương Thị Thanh Tâm',
                'username' => '206013854',
                'password' => Hash::make('Bitmo123'),
                'gender' => 1,
                'birthday' => Carbon::createFromFormat('d/m/Y', '23/03/1995'),
                'residence' => 'Thôn 3, Bình Dương, Thăng Bình, Quảng Nam',
                'phone' => '01263693771',
                'email' => 'thanhtam.cna02@gmail.com',
                'is_admin' => 0,
                'avatar' => config('adminlte.avatar-female'),
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => null,
            ],
            [
                'name' => 'Member',
                'username' => '000000001',
                'password' => Hash::make('Bitmo123'),
                'gender' => 1,
                'birthday' => Carbon::createFromFormat('d/m/Y', '23/03/1995'),
                'residence' => 'Thôn 3, Bình Dương, Thăng Bình, Quảng Nam',
                'phone' => '01263693771',
                'email' => 'member@gmail.com',
                'is_admin' => 0,
                'avatar' => config('adminlte.avatar-female'),
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
                'modified_by' => null,
            ]
        ]);
    }
}
