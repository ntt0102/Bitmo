<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'WelcomeController@index')->name('welcome');

/**
 * Register the typical authentication routes for an application.
 * Replacing: Auth::routes();
 */
Route::group(['namespace' => 'Auth'], function () {
    // Authentication Routes...
    $this->get('login', 'LoginController@showLoginForm')->name('login');
    $this->post('login', 'LoginController@login');
    $this->post('logout', 'LoginController@logout')->name('logout');

    // Registration Routes...
    if (config('adminlte.registration_open')) {
        $this->get('register', 'RegisterController@showRegistrationForm')->name('register');
        $this->post('register', 'RegisterController@register');
        $this->post('register/captcha', 'RegisterController@refreshCaptcha')->name('captcha');
    }

    // Password Reset Routes...
    $this->get('password/sms', 'ForgotPasswordController@sms')->name('password.sms');
    $this->get('password/reset', 'ForgotPasswordController@showLinkRequestForm')->name('password.request');
    $this->post('password/email', 'ForgotPasswordController@sendResetLinkEmail')->name('password.email');
    $this->get('password/reset/{token}', 'ResetPasswordController@showResetForm')->name('password.reset');
    $this->post('password/reset', 'ResetPasswordController@reset');
});

// Redirect to /dashboard
Route::get('/home', 'HomeController@index')->name('home');

/**
 * Requires authentication.
 */
Route::group(['middleware' => 'auth'], function () {

    /**
     * Dashboard. Common access.
     * // Matches The "/dashboard/*" URLs
     */
    Route::group(['prefix' => 'dashboard', 'namespace' => 'Dashboard', 'as' => 'dashboard::'], function () {
        /**
         * Dashboard Index
         * // Route named "dashboard::index"
         */
        Route::get('/', ['as' => 'index', 'uses' => 'IndexController@index']);

        /**
         * Profile
         * // Route named "dashboard::profile"
         */
        Route::get('profile', ['as' => 'profile', 'uses' => 'ProfileController@showProfile']);
        Route::post('profile', ['as' => 'profile.update', 'uses' => 'ProfileController@updateProfile']);
        Route::get('profile/downloadPDF', ['as' => 'profile.downloadPDF', 'uses' => 'ProfileController@downloadPDF']);
        Route::post('profile/settings', ['as' => 'profile.settings', 'uses' => 'ProfileController@updateSettings']);
        Route::post('profile/avatar', ['as' => 'profile.avatar', 'uses' => 'ProfileController@updateAvatar']);

        /**
         * Setting
         * // Route named "dashboard::settings"
         */
        Route::post('settings/save', ['as' => 'settings.save', 'uses' => 'SettingsController@save']);

        /**
         * Contract
         * // Route named "dashboard::contracts.*"
         */
        Route::resource('contracts', 'ContractsController');
        Route::post('contracts/{contract}/close', ['as' => 'contracts.close', 'uses' => 'ContractsController@close']);
        Route::get('contracts/{contract}/downloadPDF', ['as' => 'contracts.downloadPDF', 'uses' => 'ContractsController@downloadPDF']);

        /**
         * Messages
         * // Route named "dashboard::messages"
         */
        Route::get('messages', ['as' => 'messages', 'uses' => 'MessagesController@index']);
        Route::post('messages/markAsRead', ['as' => 'messages.markAsRead', 'uses' => 'MessagesController@markAsRead']);
        Route::post('messages/save', ['as' => 'messages.save', 'uses' => 'MessagesController@save']);
        Route::post('messages/destroy', ['as' => 'messages.destroy', 'uses' => 'MessagesController@destroy']);
        Route::post('messages/getIntervals', ['as' => 'messages.getIntervals', 'uses' => 'MessagesController@getIntervals']);
        Route::post('messages/getMessage', ['as' => 'messages.getMessage', 'uses' => 'MessagesController@getMessage']);

        /**
         * Notifications
         * // Route named "dashboard::notifications"
         */
        Route::get('notifications', ['as' => 'notifications', 'uses' => 'NotificationsController@showNotifications']);
        Route::post('notifications/markAsReadAll', ['as' => 'notifications.markAsReadAll', 'uses' => 'NotificationsController@markAsReadAll']);
        Route::post('notifications/{notification}/markAsRead', ['as' => 'notifications.markAsRead', 'uses' => 'NotificationsController@markAsRead']);
        Route::post('notifications/getIntervals', ['as' => 'notifications.getIntervals', 'uses' => 'NotificationsController@getIntervals']);

        /**
         * Money Transactions
         * // Route named "dashboard::money_transactions.*"
         */
        Route::resource('money_transactions', 'MoneyTransactionsController');

    });

    /**
     * // Matches The "/admin/*" URLs
     */
    Route::group(['prefix' => 'admin', 'namespace' => 'Admin', 'as' => 'admin::'], function () {
        /**
         * Admin Access
         */
        Route::group(['middleware' => 'admin'], function () {
            /**
             * Admin Index
             * // Route named "admin::index"
             */
            Route::get('/', ['as' => 'index', 'uses' => 'IndexController@index']);

            /**
             * Manage Users.
             * // Routes name "admin::users.*"
             */
            Route::resource('users', 'UsersController');
            Route::get('users/{user}/downloadPDF', ['as' => 'users.downloadPDF', 'uses' => 'UsersController@downloadPDF']);
            Route::post('users/avatar', ['as' => 'users.avatar', 'uses' => 'UsersController@updateAvatar']);

            /**
             * Money Transactions
             * // Route named "admin::money_transactions.*"
             */
            Route::resource('money_transactions', 'MoneyTransactionsController');
            Route::post('money_transactions/{money_transaction}/confirm', ['as' => 'money_transactions.confirm', 'uses' => 'MoneyTransactionsController@confirm']);
            
            /**
             * Contract
             * // Route named "admin::contracts.*"
             */
            Route::resource('contracts', 'ContractsController');
            Route::post('contracts/{contract}/close', ['as' => 'contracts.close', 'uses' => 'ContractsController@close']);
            Route::post('contracts/{contract}/confirm/open', ['as' => 'contracts.confirm.open', 'uses' => 'ContractsController@openConfirm']);
            Route::post('contracts/{contract}/confirm/close', ['as' => 'contracts.confirm.close', 'uses' => 'ContractsController@closeConfirm']);
            Route::get('contracts/{contract}/downloadPDF', ['as' => 'contracts.downloadPDF', 'uses' => 'ContractsController@downloadPDF']);
            /**
             * Constant
             * // Route named "admin::constants.*"
             */
            Route::resource('constants', 'ConstantsController');
            
            /**
             * Classify
             * // Route named "admin::classifies.*"
             */
            Route::resource('classifies', 'ClassifiesController');

            /**
             * Log
             * // Route named "admin::logs"
             */
            Route::get('logs', ['as' => 'logs', 'uses' => 'LogsController@showLog']);

            /**
             * Group Member
             * // Route named "admin::group-members"
             */
            Route::get('group-members', ['as' => 'group-members', 'uses' => 'GroupMembersController@index']);
            Route::post('group-members/add', ['as' => 'group-members.add', 'uses' => 'GroupMembersController@add']);
            Route::post('group-members/{member}/destroy', ['as' => 'group-members.destroy', 'uses' => 'GroupMembersController@destroy']);
        });
    });

});
