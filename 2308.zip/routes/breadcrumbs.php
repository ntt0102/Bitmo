<?php

// // Home
// Breadcrumbs::register('home', function ($breadcrumbs) {
//     $breadcrumbs->push('Trang chủ', route('welcome'));
// });

// // Home > Login
// Breadcrumbs::register('login', function ($breadcrumbs) {
//     $breadcrumbs->parent('home');
//     $breadcrumbs->push('Đăng nhập', route('login'));
// });

// if (config('adminlte.registration_open')) {
//     // Home > Register
//     Breadcrumbs::register('register', function ($breadcrumbs) {
//         $breadcrumbs->parent('home');
//         $breadcrumbs->push('Đăng ký', route('register'));
//     });
// }

// // Home > Login > Forgot Password
// Breadcrumbs::register('password-forgot', function ($breadcrumbs) {
//     $breadcrumbs->parent('login');
//     $breadcrumbs->push('Quên mật khẩu', route('password.forgot'));
// });

// // Home > Login > Forgot Password > Reset Password
// Breadcrumbs::register('password-reset', function ($breadcrumbs) {
//     $breadcrumbs->parent('password-forgot');
//     $breadcrumbs->push('Lấy lại mật khẩu', route('password.reset'));
// });

// Dashboard
Breadcrumbs::register('dashboard', function ($breadcrumbs) {
    $breadcrumbs->push('Trang chủ', route('dashboard::index'));
});

// Dashboard > Profile
Breadcrumbs::register('profile', function ($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Hồ sơ cá nhân', route('dashboard::profile'));
});

// Dashboard / {Resource} / {List|Edit|Create}
$resources = [
    'money_transactions' => 'Giao dịch tiền',
    'contracts' => 'Giao dịch hợp đồng',
];
foreach ($resources as $resource => $data) {
    $parent = 'dashboard';
    $title = $data;
    if (is_array($data)) {
        $title = $data['title'];
        $parent = $data['parent'];
    }
    $resource = 'dashboard::' . $resource;

    // List
    Breadcrumbs::register($resource, function ($breadcrumbs) use ($resource, $title, $parent) {
        $breadcrumbs->parent($parent);
        $breadcrumbs->push($title, route($resource.'.index'));
    });
    // Create
    Breadcrumbs::register($resource.'.create', function ($breadcrumbs) use ($resource) {
        $breadcrumbs->parent($resource);
        $breadcrumbs->push('Thêm', route($resource.'.create'));
    });
    // Edit
    Breadcrumbs::register($resource.'.edit', function ($breadcrumbs, $id) use ($resource) {
        $breadcrumbs->parent($resource);
        $breadcrumbs->push('Sửa', route($resource.'.edit', $id));
    });
}

// Dashboard > Notifications
Breadcrumbs::register('notifications', function ($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Thông báo', route('dashboard::notifications'));
});

// Dashboard > Messages
Breadcrumbs::register('messages', function ($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Tin nhắn', route('dashboard::messages'));
});

// Admin
Breadcrumbs::register('admin', function ($breadcrumbs) {
    $breadcrumbs->push('Trang chủ', route('admin::index'));
});

// Admin / {Resource} / {List|Edit|Create}
$resources = [
    'users' => 'Thành viên',
    'money_transactions' => 'Giao dịch tiền',
    'contracts' => 'Giao dịch hợp đồng',
    'constants' => 'Định danh',
    'classifies' => 'Danh mục',
];
foreach ($resources as $resource => $data) {
    $parent = 'admin';
    $title = $data;
    if (is_array($data)) {
        $title = $data['title'];
        $parent = $data['parent'];
    }
    $resource = 'admin::' . $resource;

    // List
    Breadcrumbs::register($resource, function ($breadcrumbs) use ($resource, $title, $parent) {
        $breadcrumbs->parent($parent);
        $breadcrumbs->push($title, route($resource.'.index').'?record_status='.get_default_record_status());
    });
    // Create
    Breadcrumbs::register($resource.'.create', function ($breadcrumbs) use ($resource) {
        $breadcrumbs->parent($resource);
        $breadcrumbs->push('Thêm', route($resource.'.create'));
    });
    // Edit
    Breadcrumbs::register($resource.'.edit', function ($breadcrumbs, $id) use ($resource) {
        $breadcrumbs->parent($resource);
        $breadcrumbs->push('Sửa', route($resource.'.edit', $id));
    });
}

// Admin > Logs
Breadcrumbs::register('logs', function ($breadcrumbs) {
    $breadcrumbs->parent('admin');
    $breadcrumbs->push('Nhật ký', route('admin::logs'));
});

// Admin > Group Members
Breadcrumbs::register('group-members', function ($breadcrumbs) {
    $breadcrumbs->parent('admin');
    $breadcrumbs->push('Nhóm thành viên', route('admin::group-members'));
});
